package com.org.childmonitorparent.parent.activities

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.chip.Chip
import com.org.childmonitorparent.R
import com.org.childmonitorparent.child.viewmodels.SearchLogsViewModel
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.databinding.ActivitySearchLogsBinding
import com.org.childmonitorparent.databinding.CustomToolbarBinding
import com.org.childmonitorparent.parent.models.ChildInfo

class SearchLogsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchLogsBinding
    private lateinit var customToolbarBinding: CustomToolbarBinding
    private val searchLogsViewModel: SearchLogsViewModel by viewModels()
    private lateinit var childId: String
    private var blockedKeywords = mutableListOf<String>()
    private var searchQueryList = mutableListOf<String>()


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchLogsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        customToolbarBinding = binding.toolBar
        customToolbarBinding.leftAction.setOnClickListener {
            finish()
        }

        val childInfo = intent.getSerializableExtra("childInfo") as? ChildInfo
        if (childInfo != null) {
            childId = childInfo.childId
            customToolbarBinding.title.text = "${childInfo.name} Browse history"
        }

        searchLogsViewModel.blockedKeywords.observe(this) { blocked ->
            blockedKeywords.clear()
            blockedKeywords.addAll(blocked)
        }

        searchLogsViewModel.searchLogs.observe(this) { logs ->
            binding.chipGroup.removeAllViews()
            searchQueryList.clear()
            if (logs.isNotEmpty()) {
                searchQueryList.addAll(logs)
                searchQueryList.forEach { query ->
                    addQueryChip(query)
                }
            }
        }

        searchLogsViewModel.listenForBlockedKeywords(childId)
        searchLogsViewModel.getChildSearchHistory(childId)
    }

    private fun addQueryChip(query: String) {
        val chip = Chip(this)
        chip.text = query
        chip.isCloseIconVisible = false // No delete option
        chip.setChipBackgroundColorResource(R.color.chip_selector)
        chip.isCheckable = true
        chip.isChecked = blockedKeywords.contains(query)
        binding.chipGroup.addView(chip)
        chip.setOnClickListener {
            if (chip.isChecked) {
                chip.setTextColor(ContextCompat.getColor(this, R.color.white))
                blockedKeywords.add(query)
            } else {
                chip.setTextColor(ContextCompat.getColor(this, R.color.dark_gray))
                blockedKeywords.remove(query)
            }
            searchLogsViewModel.saveBlockedKeyword(childId, blockedKeywords)
        }
    }
}