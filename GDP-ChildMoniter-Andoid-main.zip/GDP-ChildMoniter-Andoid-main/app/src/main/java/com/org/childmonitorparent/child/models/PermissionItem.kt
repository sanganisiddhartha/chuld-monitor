package com.org.childmonitorparent.child.models

data class PermissionItem(
    val permission: String,
    val label: String,
    var isGranted: Boolean
)
