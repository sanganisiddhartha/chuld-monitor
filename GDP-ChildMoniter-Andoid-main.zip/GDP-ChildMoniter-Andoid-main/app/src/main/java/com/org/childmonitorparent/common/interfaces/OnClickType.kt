package com.org.childmonitorparent.common.interfaces

interface OnClickType {
    fun onClick(position: Int, type: String)
}