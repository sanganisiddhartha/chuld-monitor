package com.org.childmonitorparent.child.broadcast_receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.org.childmonitorparent.child.services.LocationService
import com.org.childmonitorparent.common.utils.ServiceHelper

class StartServicesReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        println("StartServicesReceiver: ${intent.action}")
        when (intent.action) {
            "NotificationServiceDestroyed" -> {
                ServiceHelper.startCallService(context)
            }

            "BlockAppsServiceDestroyed" -> {
                ServiceHelper.startBlockAppsService(context)
            }

            "DeviceLockServiceDestroyed" -> {
                ServiceHelper.startDeviceLockService(context)
            }

            "LocationServiceDestroyed" -> {
                ServiceHelper.startLocationService(
                    context,
                    Intent(context, LocationService::class.java)
                )
            }

            Intent.ACTION_BOOT_COMPLETED -> {
                ServiceHelper.startLocationService(
                    context,
                    Intent(context, LocationService::class.java)
                )
                ServiceHelper.startDeviceLockService(context)
                ServiceHelper.startBlockAppsService(context)
            }

            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                ServiceHelper.startLocationService(
                    context,
                    Intent(context, LocationService::class.java)
                )
                ServiceHelper.startDeviceLockService(context)
                ServiceHelper.startBlockAppsService(context)
            }
        }
    }
}
