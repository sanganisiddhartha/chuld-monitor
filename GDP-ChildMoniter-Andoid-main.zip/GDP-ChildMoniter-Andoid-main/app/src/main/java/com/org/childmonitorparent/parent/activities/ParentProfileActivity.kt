package com.org.childmonitorparent.parent.activities

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.org.childmonitorparent.R
import com.org.childmonitorparent.auth.models.User
import com.org.childmonitorparent.auth.viewmodels.AuthViewModel
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.databinding.ActivityParentProfileBinding
import com.org.childmonitorparent.databinding.CustomToolbarBinding

class ParentProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityParentProfileBinding
    private lateinit var customToolbar: CustomToolbarBinding
    private val authViewModel: AuthViewModel by viewModels()
    private var userId = ""
    private lateinit var userDetails: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityParentProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        customToolbar = binding.toolBar
        customToolbar.title.text = getString(R.string.profile_details)
        customToolbar.leftAction.setOnClickListener {
            finish()
        }
        customToolbar.rightAction.visibility = View.VISIBLE
        customToolbar.rightAction.setImageResource(R.drawable.ic_check)
        customToolbar.rightAction.imageTintList = getColorStateList(R.color.black)
        customToolbar.rightAction.setOnClickListener {
            if (binding.phoneNumber.text.toString().isEmpty() || binding.phoneNumber.text.toString().length < 10) {
                Toast.makeText(this, "Please enter valid phone number", Toast.LENGTH_SHORT).show()
            }else{
                userDetails.phone = binding.phoneNumber.text.toString()
                authViewModel.updateUser(this, userId, userDetails) {
                    if (it) {
                        Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show()
                        finish()
                    } else Toast.makeText(this, "Failed to update profile", Toast.LENGTH_SHORT).show()
                }
            }
        }
        userId = PrefsHelper.getData("userId")
        authViewModel.userDetails.observe(this) {
            it?.let {
                userDetails = it
                setProfileDetails()
            }
        }
        authViewModel.getUserFromId(userId) {

        }
    }

    private fun setProfileDetails() {
        binding.name.text = userDetails.username
        binding.email.text = userDetails.email
        binding.phoneNumber.setText(userDetails.phone)
    }
}