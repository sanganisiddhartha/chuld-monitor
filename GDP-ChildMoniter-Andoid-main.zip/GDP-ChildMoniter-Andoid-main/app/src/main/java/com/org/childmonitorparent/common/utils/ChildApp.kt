package com.org.childmonitorparent.common.utils

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import com.org.childmonitorparent.parent.activities.KidsListActivity
import com.org.childmonitorparent.auth.activities.LoginActivity
import com.org.childmonitorparent.child.activities.ChildMainActivity
import com.org.childmonitorparent.parent.activities.ChildDetailsActivity

class ChildApp : Application() {
    private lateinit var context: Context
    override fun onCreate() {
        super.onCreate()
        context = applicationContext
        PrefsHelper.init(context)
        //createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                "location_channel",
                "Child Location Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }
}