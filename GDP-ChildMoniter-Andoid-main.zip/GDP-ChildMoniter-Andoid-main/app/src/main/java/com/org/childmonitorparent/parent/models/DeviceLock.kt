package com.org.childmonitorparent.parent.models

data class DeviceLock (val childId: String, val lock: Boolean, val timestamp: Long?){
    constructor() : this("",false, null)
}