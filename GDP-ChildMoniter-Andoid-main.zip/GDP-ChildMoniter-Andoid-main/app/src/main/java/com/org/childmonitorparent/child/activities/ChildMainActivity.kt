package com.org.childmonitorparent.child.activities

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.utils.ServiceHelper
import com.org.childmonitorparent.databinding.ActivityChildMainBinding
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.databinding.CustomToolbarBinding
import com.org.childmonitorparent.parent.activities.SettingsActivity
import com.org.childmonitorparent.parent.models.ChildInfo
import com.org.childmonitorparent.parent.viewmodels.AddChildViewModel

class ChildMainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChildMainBinding
    private lateinit var customToolbarBinding: CustomToolbarBinding
    private lateinit var childInfo: ChildInfo
    private val addChildViewModel: AddChildViewModel by viewModels()
    private val sharedViewModel: SharedViewModel<ChildInfo> by viewModels()
    private lateinit var roomId: String

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChildMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        customToolbarBinding = binding.toolBar
        customToolbarBinding.leftAction.visibility = View.GONE
        customToolbarBinding.rightAction.setImageResource(R.drawable.ic_settings)
        customToolbarBinding.rightAction.visibility = View.VISIBLE
        customToolbarBinding.rightAction.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java).putExtra("isChild", true))
        }

        addChildViewModel.childInfo.observe(this) {
            if (it != null) {
                childInfo = it
                roomId = "${it.parentId}_${it.childId}"
                customToolbarBinding.title.text = it.name.uppercase()
                addChildViewModel.getParentName(it.parentId)
                sharedViewModel.setChildInfo(it)
                ServiceHelper.startCallService(this)
            }
        }

        addChildViewModel.getChildInfo()

        // ✅ Fix: Use correct NavController ID
        val navView: BottomNavigationView = binding.navView
        val navController =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment)?.findNavController()
        navController?.let {
            navView.setupWithNavController(it)
        }
    }
}