package com.org.childmonitorparent.child.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.org.childmonitorparent.child.models.PermissionItem
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.databinding.PermissionItemBinding

class PermissionAdapter(
    private val permissionList: List<PermissionItem>,
    private val onClickTypeValue: OnClickTypeValue
) : RecyclerView.Adapter<PermissionAdapter.PermissionViewHolder>() {

    inner class PermissionViewHolder(private val binding: PermissionItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(permission: PermissionItem) {
            binding.permissionLabel.text = permission.label
            binding.permissionSwitch.isChecked = permission.isGranted
            binding.permissionSwitch.setOnCheckedChangeListener { _, isChecked ->
                //permission.isGranted = isChecked
                onClickTypeValue.onClick(adapterPosition, permission.permission, "$isChecked")
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PermissionViewHolder {
        val binding =
            PermissionItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PermissionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PermissionViewHolder, position: Int) {
        holder.bind(permissionList[position])
    }

    override fun getItemCount(): Int = permissionList.size
}
