package com.org.childmonitorparent.auth.activities

import android.content.Intent
import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.org.childmonitorparent.R
import com.org.childmonitorparent.databinding.ActivityLoginBinding
import com.org.childmonitorparent.parent.activities.KidsListActivity
import com.org.childmonitorparent.auth.viewmodels.AuthViewModel
import com.org.childmonitorparent.child.activities.ChildMainActivity
import com.org.childmonitorparent.common.utils.DialogHelper
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.utils.ProgressDialogHelper
import com.org.childmonitorparent.common.utils.Validators

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun onLoginClick(view: View) {
        val email = binding.email.text.toString().trim()
        val password = binding.password.text.toString().trim()
        // Perform login logic here
        if (email.isNotEmpty() && password.isNotEmpty()) {
            val authViewModel = AuthViewModel()
            authViewModel.login(this, email, password) { success ->
                if (success) {
                    Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show()
                    if (PrefsHelper.getData("userType") == "Parent")
                        startActivity(Intent(this, KidsListActivity::class.java))
                    else startActivity(Intent(this, ChildMainActivity::class.java))
                    finish()
                } else Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show()
        }
    }

    fun onSignUpClick(view: View) {
        startActivity(Intent(this, SignUpActivity::class.java))
    }

    fun onPasswordVisibilityClick(view: View) {
        val isPasswordVisible = binding.password.transformationMethod == null
        if (isPasswordVisible) {
            // Hide password
            binding.password.transformationMethod = PasswordTransformationMethod.getInstance()
            binding.togglePassword.setImageResource(R.drawable.ic_eye_visibility) // Change icon
        } else {
            // Show password
            binding.password.transformationMethod = null
            binding.togglePassword.setImageResource(R.drawable.ic_eye_visibility_off) // Change icon
        }
        // Move cursor to the end of the text
        binding.password.setSelection(binding.password.text?.length ?: 0)
    }

    fun onForgotPasswordClick(view: View) {
        DialogHelper.showForgotPasswordDialog(this) { success, email ->
            if (success) {
                AuthViewModel().forgotPassword(email) {
                    if (it)
                        Toast.makeText(
                            this,
                            "Password reset link sent to $email",
                            Toast.LENGTH_SHORT
                        ).show()
                    else Toast.makeText(this, "Password reset failed", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Password reset failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}