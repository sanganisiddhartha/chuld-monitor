package com.org.childmonitorparent.common.chats

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.org.childmonitorparent.databinding.ActivityVideoPlayerBinding
import com.org.childmonitorparent.databinding.CustomToolbarBinding

class VideoPlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoPlayerBinding
    private lateinit var customToolbarBinding: CustomToolbarBinding
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVideoPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        customToolbarBinding = binding.toolbar
        customToolbarBinding.leftAction.setOnClickListener {
            finish()
        }

        // Get Video URL from Intent
        val videoUrl = intent.getStringExtra("video_url") ?: return

        // Initialize ExoPlayer
        player = ExoPlayer.Builder(this).build()
        binding.playerView.player = player

        // Set Video Source
        val mediaItem = MediaItem.fromUri(Uri.parse(videoUrl))
        player?.setMediaItem(mediaItem)
        player?.prepare()
        player?.playWhenReady = true
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()  // Release player when activity is destroyed
    }
}