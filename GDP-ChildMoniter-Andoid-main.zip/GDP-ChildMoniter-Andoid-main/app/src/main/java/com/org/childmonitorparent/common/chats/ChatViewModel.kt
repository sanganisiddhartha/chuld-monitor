package com.org.childmonitorparent.common.chats

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import com.org.childmonitorparent.common.utils.PrefsHelper

class ChatViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()
    private var _chatList = MutableLiveData<List<ChatMessage>>()
    val chatList: LiveData<List<ChatMessage>> = _chatList
    private var isChatScreenActive: Boolean = false

    fun setChatScreenActive(isActive: Boolean) {
        isChatScreenActive = isActive
    }

    fun sendMessage(chatRoomId: String, message: ChatMessage, callback: (Boolean) -> Unit) {
        val messageRef = db.collection("chats")
            .document(chatRoomId)
            .collection("messages").document()

        val messageWithId = message.copy(messageId = messageRef.id, status = MessageStatus.SENDING)

        messageRef.set(messageWithId)
            .addOnSuccessListener {
                messageRef.update("status", MessageStatus.SENT)
                    .addOnSuccessListener {
                        // Message sent successfully
                        sendChatNotification(chatRoomId, message)
                        callback(true)
                    }
                    .addOnFailureListener { callback(false) }

            }
            .addOnFailureListener {
                callback(false) // Failed to send message
            }
    }

    private fun sendChatNotification(chatRoomId: String, message: ChatMessage) {
        val notificationData = hashMapOf(
            "isShowNotification" to true,
            "senderName" to PrefsHelper.getData("userName"),
            "receiverId" to message.receiverId,
            "message" to message.message,
            "timestamp" to System.currentTimeMillis(),
        )
        db.collection("chat_notifications")
            .document(chatRoomId)
            .set(notificationData)
            .addOnSuccessListener {
                println("✅ Chat notification sent successfully")
            }
            .addOnFailureListener { e ->
                println("❌ Failed to send chat notification: ${e.message}")
            }
    }

    fun listenForMessages(chatRoomId: String) {
        db.collection("chats")
            .document(chatRoomId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    println("Error fetching messages: ${e.message}")
                    return@addSnapshotListener
                }

                val messages =
                    snapshots?.documents?.mapNotNull { it.toObject(ChatMessage::class.java) }
                        ?: emptyList()

                if (messages.isNotEmpty()) {
                    _chatList.value = messages // Update UI
                    // Check if user is currently in the chat screen
                    if (isChatScreenActive)
                        markAllUnreadMessagesAsRead(chatRoomId)
                }
            }
    }

    private fun markAllUnreadMessagesAsRead(chatRoomId: String) {
        val messagesRef = db.collection("chats")
            .document(chatRoomId)
            .collection("messages")

        // Query all messages where status is "UNREAD" and receiverId matches the user
        messagesRef.whereEqualTo("status", MessageStatus.SENT)
            .whereEqualTo("receiverId", PrefsHelper.getData("userId"))
            .get()
            .addOnSuccessListener { documents ->
                val batch = db.batch()
                documents.forEach { document ->
                    batch.update(document.reference, "status", MessageStatus.READ)
                }
                batch.commit()
                    .addOnSuccessListener {
                        println("✅ Successfully marked all unread messages as READ")
                    }
                    .addOnFailureListener { e ->
                        println("❌ Failed to update messages: ${e.message}")
                    }
            }
    }

    fun uploadMediaToFirebase(uri: Uri, fileType: String, onComplete: (String?) -> Unit) {
        val storageRef = FirebaseStorage.getInstance().reference
        val fileName = "${System.currentTimeMillis()}_${uri.lastPathSegment}"
        val fileRef = storageRef.child("chat_media/$fileType/$fileName")

        fileRef.putFile(uri)
            .addOnSuccessListener { taskSnapshot ->
                fileRef.downloadUrl.addOnSuccessListener { downloadUri ->
                    onComplete(downloadUri.toString()) // Return URL
                }
            }
            .addOnFailureListener { e ->
                println("❌ Failed to upload file: ${e.message}")
                onComplete(null)
            }
    }
}