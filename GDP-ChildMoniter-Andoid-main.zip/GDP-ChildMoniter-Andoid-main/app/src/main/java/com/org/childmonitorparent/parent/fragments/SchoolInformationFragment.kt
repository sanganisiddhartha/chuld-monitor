package com.org.childmonitorparent.parent.fragments

import android.app.Activity.RESULT_OK
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.org.childmonitorparent.R
import com.org.childmonitorparent.databinding.FragmentSchoolInformationBinding
import com.org.childmonitorparent.parent.activities.PinLocationActivity
import com.org.childmonitorparent.parent.models.AddChildInfo
import com.org.childmonitorparent.parent.viewmodels.AddChildViewModel

class SchoolInformationFragment : Fragment() {

    private var _binding: FragmentSchoolInformationBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var addChildInfo: AddChildInfo
    private val addChildViewModel : AddChildViewModel by activityViewModels()
    private lateinit var schoolLocation: String
    private lateinit var context: Context

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSchoolInformationBinding.inflate(inflater, container, false)
        context = requireContext()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //addChildInfo = arguments?.getSerializable("addChildInfo") as AddChildInfo
        addChildInfo =
            addChildViewModel.getAddChildInfo() ?: AddChildInfo("", "", "", "", "", "", "", "", "")
        Log.d("Add Child", addChildInfo.name)

        binding.pinSchoolLocation.setOnClickListener {
            val intent = Intent(context, PinLocationActivity::class.java)
            locationPickerLauncher.launch(intent)
        }

        binding.btnContinue.setOnClickListener {
            if (binding.etSchoolName.text.toString()
                    .isEmpty() || binding.tvSchoolLocation.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT)
                    .show()
            } else {
                addChildInfo.schoolName = binding.etSchoolName.text.toString()
                addChildInfo.schoolAddress = binding.tvSchoolLocation.text.toString()
                addChildInfo.schoolLocation = schoolLocation
                addChildViewModel.setAddChildInfo(addChildInfo)
                addChildViewModel.saveChildInfo(context, addChildInfo) { success ->
                    if (success) findNavController().navigate(R.id.action_thirdFragment_to_fourthFragment)
                    else Toast.makeText(
                        context,
                        "Something went wrong",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }
            }
        }
        binding.btnCancel.setOnClickListener {
            findNavController().navigate(R.id.action_thirdFragment_to_secondFragment)
        }
    }

    private val locationPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val latitude = data?.getDoubleExtra("latitude", 0.0) ?: 0.0
            val longitude = data?.getDoubleExtra("longitude", 0.0) ?: 0.0
            schoolLocation = "$latitude,$longitude"
            val address = data?.getStringExtra("address") ?: "Unknown Address"

            binding.tvSchoolLocation.text = "$address"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}