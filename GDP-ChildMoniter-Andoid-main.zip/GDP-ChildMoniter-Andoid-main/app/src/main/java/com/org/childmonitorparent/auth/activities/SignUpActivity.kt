package com.org.childmonitorparent.auth.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.installations.Utils
import com.org.childmonitorparent.R
import com.org.childmonitorparent.databinding.ActivitySignupBinding
import com.org.childmonitorparent.parent.activities.ChildLinkActivity
import com.org.childmonitorparent.auth.models.User
import com.org.childmonitorparent.auth.viewmodels.AuthViewModel
import com.org.childmonitorparent.child.activities.ChildMainActivity
import com.org.childmonitorparent.common.utils.Validators
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.parent.activities.KidsListActivity

class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding
    private var userType = "Parent"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.userType.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.parentType -> {
                    userType = "Parent"
                    binding.parentEmail.text.clear()
                    binding.parentEmail.visibility = View.GONE
                    binding.parentEmail.isEnabled = false
                }

                R.id.childType -> {
                    userType = "Child"
                    binding.parentEmail.text.clear()
                    binding.parentEmail.visibility = View.VISIBLE
                    binding.parentEmail.isEnabled = true
                }
            }
        }
    }

    fun onSignUpClick(view: View) {
        val username = binding.username.text.toString().trim()
        val email = binding.email.text.toString().trim().lowercase()
        val phone = binding.phone.text.toString().trim()
        val password = binding.password.text.toString().trim()
        val parentEmail = binding.parentEmail.text.toString().trim().lowercase()
        // Perform sign-up logic here

        if (userType == "Parent") {
            if (username.isNotEmpty() && email.isNotEmpty() && phone.isNotEmpty() && password.isNotEmpty()) {
                if (Validators.isValidPassword(password)) {
                    val user = User(userType, username, email, phone, password, "")
                    val viewModel = AuthViewModel()
                    viewModel.signUp(this, user) { success ->
                        if (success) {
                            Toast.makeText(this, "Sign up successful.", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, KidsListActivity::class.java))
                            finish()
                        } else {
                            Toast.makeText(this, "Sign up failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else Toast.makeText(
                    this,
                    "Password should be at least 6 characters, one uppercase, one lowercase, one number and one special character",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        } else {
            if (parentEmail.isNotEmpty() && username.isNotEmpty() && email.isNotEmpty() && phone.isNotEmpty() && password.isNotEmpty()) {
                if (Validators.isValidPassword(password)) {
                    val viewModel = AuthViewModel()
                    viewModel.checkParentEmailExists(parentEmail) { success, parentId ->
                        if (success) {
                            val user = User(userType, username, email, phone, password, parentId)
                            viewModel.signUp(this, user) { it ->
                                if (it) {
                                    Toast.makeText(this, "Sign up successful.", Toast.LENGTH_SHORT)
                                        .show()
                                    val intent = Intent(this, ChildLinkActivity::class.java)
                                    intent.putExtra("user", user)
                                    startActivity(intent)
                                    finish()
                                } else {
                                    Toast.makeText(this, "Sign up failed", Toast.LENGTH_SHORT)
                                        .show()
                                }
                            }
                        } else {
                            Toast.makeText(this, "Parent email not found", Toast.LENGTH_SHORT)
                                .show()
                        }
                    }
                } else Toast.makeText(
                    this,
                    "Password should be at least 6 characters, one uppercase, one lowercase, one number and one special character",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun onLoginClick(view: View) {
        startActivity(Intent(this, LoginActivity::class.java))
    }
}