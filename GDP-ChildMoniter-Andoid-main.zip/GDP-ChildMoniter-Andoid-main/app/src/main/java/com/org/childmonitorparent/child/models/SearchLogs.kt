package com.org.childmonitorparent.child.models

data class SearchLogs(
    val query: String,
    val timestamp: Long,
    val childId: String
)
