package com.org.childmonitorparent.common.viewmodels

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.org.childmonitorparent.common.models.AppsInfo
import com.org.childmonitorparent.common.utils.Base64Functions.drawableToBase64
import com.org.childmonitorparent.common.utils.ProgressDialogHelper

class AppsViewModel(private val context: Context) : ViewModel() {
    private val db = FirebaseFirestore.getInstance()

    private var _childApps = MutableLiveData<List<AppsInfo?>>()
    val childApps: MutableLiveData<List<AppsInfo?>> = _childApps
    private var _blockedApps = MutableLiveData<List<String>>()
    val blockedApps: MutableLiveData<List<String>> = _blockedApps

    fun getUserInstalledApps(context: Context): List<AppsInfo> {
        val packageManager = context.packageManager
        val installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)

        val appsList = installedApps.filter {
            (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 // ✅ Exclude system apps
        }.mapNotNull { appInfo ->
            try {
                val iconDrawable = appInfo.loadIcon(packageManager)
                //val iconBase64 = drawableToBase64(iconDrawable) // ✅ Convert to Base64 safely
                AppsInfo(
                    appIcon = "iconBase64",
                    appName = packageManager.getApplicationLabel(appInfo).toString(),
                    packageName = appInfo.packageName
                )
            } catch (e: Exception) {
                e.printStackTrace()
                null // ✅ Skip this app if there's an error
            }
        }
        return appsList
    }

    @SuppressLint("QueryPermissionsNeeded")
    @RequiresApi(Build.VERSION_CODES.O)
    fun getAllInstalledApps(context: Context): List<AppsInfo> {
        val packageManager = context.packageManager
        val installedApps =
            packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        val appsList = installedApps.mapNotNull {
            try {
                val iconDrawable = it.loadIcon(packageManager)
                val iconBase64 = drawableToBase64(iconDrawable) // ✅ Convert to Base64 safely
                AppsInfo(
                    appIcon = "iconBase64",
                    appName = packageManager.getApplicationLabel(it).toString(),
                    packageName = it.packageName
                )
            } catch (e: Exception) {
                e.printStackTrace()
                emptyList<AppsInfo>() // ✅ Skip this app if there's an error
            }
        }
        return appsList as List<AppsInfo>
    }

    fun saveChildApps(childId: String, appsList: List<AppsInfo>) {
        if (appsList.isEmpty()) {
            Log.e("Firestore", "No apps to save")
            return
        }
        val docRef = db.collection("child_apps").document(childId) // 🔥 Store under childId
        // ✅ Store apps list inside Firestore document
        val data = mapOf("apps_list" to appsList)

        docRef.set(data, SetOptions.merge()) // 🔥 Merge instead of overwrite
            .addOnSuccessListener {
                println("All apps saved and synced in real-time")
            }
            .addOnFailureListener { e ->
                println("Error saving apps $e")
            }
    }


    fun getChildApps(childId: String) {
        ProgressDialogHelper.showProgressDialog(context, "Fetching Apps...")
        val childAppsRef = db.collection("child_apps").document(childId)
        // 🔹 Listen for real-time updates
        childAppsRef.addSnapshotListener { document, error ->
            ProgressDialogHelper.hideProgressDialog()
            if (error != null) {
                println("Firestore listen failed: ${error.message}")
                return@addSnapshotListener
            }
            if (document != null && document.exists()) {
                val appsList =
                    document.get("apps_list") as? List<HashMap<String, Any>> ?: emptyList()

                val childApps = appsList.mapNotNull { appData ->
                    try {
                        AppsInfo(
                            appIcon = appData["appIcon"] as? String ?: "",
                            appName = appData["appName"] as? String ?: "Unknown",
                            packageName = appData["packageName"] as? String ?: ""
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        null
                    }
                }
                _childApps.value = childApps // ✅ LiveData updates automatically
            } else {
                ProgressDialogHelper.hideProgressDialog()
                _childApps.value = emptyList()
            }
        }
    }


    fun updateChildAppsStatus(childId: String, packageName: String, isBlocked: Boolean) {
        val childAppsRef = db.collection("child_apps").document(childId)

        childAppsRef.get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val appsList =
                        document.get("apps_list") as? List<HashMap<String, Any>> ?: emptyList()

                    val updatedApps = appsList.map { appData ->
                        if (appData["packageName"] == packageName) {
                            appData["isBlocked"] = isBlocked // ✅ Update Firestore Field
                        }
                        appData
                    }

                    // 🔹 Save updated list back to Firestore
                    childAppsRef.update("apps_list", updatedApps)
                        .addOnSuccessListener {
                            println("App status updated")
                        }
                        .addOnFailureListener { e ->
                            println("Error updating app status: ${e.message}")
                        }
                } else {
                    println("No apps found for child")
                }
            }
            .addOnFailureListener { e ->
                println("Error fetching child apps: ${e.message}")
            }
    }

    fun saveBlockedApps(childId: String, blockedApps: List<String>) {
        val blockedAppsRef = db.collection("blocked_apps").document(childId)

        val data = mapOf("blockedApps" to blockedApps) // 🔥 Store as a map

        blockedAppsRef.set(data, SetOptions.merge()) // 🔥 Merge instead of overwriting
            .addOnSuccessListener {
                println("Blocked apps saved successfully")
                //_blockedApps.value = blockedApps // 🔥 Update LiveData
                listenForBlockedApps(childId) // 🔥 Start listening for updates
            }
            .addOnFailureListener { e ->
                println("Error saving blocked apps $e")
            }
    }

    fun listenForBlockedApps(childId: String) {
        val blockedAppsRef = db.collection("blocked_apps").document(childId)

        blockedAppsRef.addSnapshotListener { documentSnapshot, error ->
            if (error != null) {
                println("Error listening for updates $error")
                return@addSnapshotListener
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                val blockedApps =
                    documentSnapshot.get("blockedApps") as? List<String> ?: emptyList()
                _blockedApps.value = blockedApps // 🔥 Live update in ViewModel
            } else {
                println("No blocked apps found")
                _blockedApps.value = emptyList()
            }
        }
    }

    private fun listenForChildActivityLogs(context: Context, childId: String) {
        db.collection("child_activity_logs").document(childId)
            .addSnapshotListener { document, error ->
                if (error != null) {
                    Log.e("Firestore", "Error listening for child activity logs", error)
                    return@addSnapshotListener
                }

                if (document != null && document.exists()) {
                    val logs = document.get("logs") as? List<Map<String, Any>> ?: emptyList()

                    logs.forEach { log ->
                        val packageName = log["appName"] as? String ?: "Unknown App"
                        val timestamp = log["timestamp"] as? Long ?: System.currentTimeMillis()

                        Log.d("Firestore", "Child opened blocked app")

                        // 🔥 Show Notification to Parent
                    }
                }
            }
    }
}