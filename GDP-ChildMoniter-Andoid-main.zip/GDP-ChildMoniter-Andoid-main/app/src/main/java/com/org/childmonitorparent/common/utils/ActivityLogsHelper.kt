package com.org.childmonitorparent.common.utils

import android.content.Context
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import com.org.childmonitorparent.common.models.LogItem
import com.org.childmonitorparent.common.models.LogType
import com.org.childmonitorparent.common.utils.ContactHelper.getContactName
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object ActivityLogsHelper {

    fun formatTimestamp(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM, yyyy hh:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun callLogs(context: Context): List<LogItem> {
        val callList = mutableListOf<LogItem>()

        // 🔹 Get the timestamp of today at 00:00:00
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayStartTime = calendar.timeInMillis

        val cursor = context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            null,
            "${CallLog.Calls.DATE} >= ?",  // 🔹 Query filter for today's logs
            arrayOf(todayStartTime.toString()),
            "${CallLog.Calls.DATE} DESC"
        )

        cursor?.use {
            while (it.moveToNext()) {
                val number = it.getString(it.getColumnIndexOrThrow(CallLog.Calls.NUMBER))
                val duration =
                    it.getString(it.getColumnIndexOrThrow(CallLog.Calls.DURATION)) + " sec"
                val timestamp =
                    formatTimestamp(it.getLong(it.getColumnIndexOrThrow(CallLog.Calls.DATE)))

                val type = when (it.getInt(it.getColumnIndexOrThrow(CallLog.Calls.TYPE))) {
                    CallLog.Calls.INCOMING_TYPE -> "Incoming Call"
                    CallLog.Calls.OUTGOING_TYPE -> "Outgoing Call"
                    CallLog.Calls.MISSED_TYPE -> "Missed Call"
                    else -> "Unknown"
                }

                val contactName = if (PermissionsHelper.hasReadContactsPermission(context))
                    getContactName(context, number) ?: "Unknown"
                else "Unknown"

                callList.add(
                    LogItem(
                        name = contactName,
                        number = number,
                        subtitle = type,
                        extraInfo = duration,
                        timestamp = timestamp,
                        logType = LogType.CALL
                    )
                )
            }
        }
        return callList
    }

    fun messageLogs(context: Context): List<LogItem> {
        val messageList = mutableListOf<LogItem>()
        // 🔹 Get the timestamp of today at 00:00:00
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayStartTime = calendar.timeInMillis // 🔥 Midnight timestamp of today
        val cursor = context.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            null,
            "${Telephony.Sms.DATE} >= ?",  // 🔹 Query filter for today's logs
            arrayOf(todayStartTime.toString()),
            "${Telephony.Sms.DATE} DESC"
        )
        cursor?.use {
            while (it.moveToNext()) {
                val sender = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS))
                val message = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.BODY))
                val timestamp =
                    formatTimestamp(it.getLong(it.getColumnIndexOrThrow(Telephony.Sms.DATE)))

                messageList.add(
                    LogItem(
                        name = "",
                        number = sender,
                        subtitle = "Message",
                        extraInfo = message,
                        timestamp = timestamp,
                        logType = LogType.MESSAGE
                    )
                )
            }
        }
        return messageList
    }

    fun contactLogs(context: Context): List<LogItem> {
        val contactList = mutableListOf<LogItem>()
        val contentResolver = context.contentResolver
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.Contacts.CONTACT_LAST_UPDATED_TIMESTAMP // Fetch last updated timestamp
            ),
            null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
        )

        cursor?.use {
            while (it.moveToNext()) {
                val name =
                    it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                val phoneNumber =
                    it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))

                // Fetch last updated timestamp, or use a default value
                val timestampMillis =
                    it.getLong(it.getColumnIndexOrThrow(ContactsContract.Contacts.CONTACT_LAST_UPDATED_TIMESTAMP))
                val timestamp =
                    if (timestampMillis > 0) formatTimestamp(timestampMillis) else "Unknown"

                contactList.add(
                    LogItem(
                        name = name,
                        number = phoneNumber,
                        subtitle = "",
                        extraInfo = "Saved Contact",
                        timestamp = timestamp,
                        logType = LogType.CONTACT
                    )
                )
            }
        }
        return contactList
    }
}