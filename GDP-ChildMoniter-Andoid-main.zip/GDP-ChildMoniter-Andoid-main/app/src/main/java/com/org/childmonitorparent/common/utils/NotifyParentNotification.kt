package com.org.childmonitorparent.common.utils

import android.content.Context
import android.util.Log
import com.android.volley.ClientError
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONObject
import java.io.FileInputStream
import java.io.IOException
import java.util.Arrays

object NotifyParentNotification {

    private val db by lazy { FirebaseFirestore.getInstance() }

    fun notifyParent(context: Context, parentId: String, latitude: Double, longitude: Double) {
        if (parentId.isEmpty()) return
        if (parentId == PrefsHelper.getData("userId"))
            NotificationUtils.showPushNotification(
                context,
                "Child Left Safe Zone",
                "Your child is at $latitude, $longitude"
            )
        /*db.collection("parent_devices").document(parentId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val parentToken = document.getString("fcmToken")
                    if (!parentToken.isNullOrEmpty()) {
                        sendFCMNotification(context, parentToken, latitude, longitude)
                    } else {
                        Log.e("NotifyParent", "No FCM token found for parent: $parentId")
                    }
                } else {
                    Log.e("NotifyParent", "Parent device document does not exist for: $parentId")
                }
            }
            .addOnFailureListener { e ->
                Log.e("NotifyParent", "Error fetching parent device token", e)
            }*/
    }


    fun isWithinLocation(lat: Double, lon: Double, location: Pair<Double, Double>): Boolean {
        val distance = calculateDistance(lat, lon, location.first, location.second)
        return distance <= 500 // ✅ 500 meters radius
    }

    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371e3 // Earth radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return r * c
    }

    private fun sendFCMNotification(
        context: Context,
        token: String,
        latitude: Double,
        longitude: Double
    ) {
        val projectId = "child-monitor-7860a"
        val serverKey = "1086282091629" // 🔥 Replace with your actual FCM Server Key
        val url = "https://fcm.googleapis.com/fcm/send"
        //val url = "https://fcm.googleapis.com/v1/projects/$projectId/messages:send"
        val newToken =
            "evNHNaZ8RTy6nbcPL8izCm:APA91bFl7NqttRTAGhXR5O2lfxAtFafngD4-f2TB_uta2xxCB5x5LWN3h_oiNwwGzNvW7TeNY8R6irb3G4u5FF5PO4atLmKl3eGY5h1wdFH0G_Axi4kqOow"
        /*if (serverKey == "1086282091629") {
            Log.e("FCM", "❌ FCM Server Key is missing! Check Firebase Console.")
            return
        }*/

        val notificationPayload = mapOf(
            "to" to newToken,
            "notification" to mapOf(
                "title" to "Child Left Safe Zone",
                "body" to "Your child is at $latitude, $longitude",
                "click_action" to "OPEN_MAP" // ✅ Allows parent to open a map on tap
            ),
            "data" to mapOf(
                "latitude" to latitude,
                "longitude" to longitude
            )
        )

        /*val notificationPayload = mapOf(
            "message" to mapOf(
                "token" to token,
                "notification" to mapOf(
                    "title" to "Child Left Safe Zone",
                    "body" to "Your child is at $latitude, $longitude"
                ),
                "data" to mapOf(
                    "latitude" to latitude,
                    "longitude" to longitude
                )
            )
        )*/

        val jsonRequest = JSONObject(notificationPayload)

        val request = object : JsonObjectRequest(
            Request.Method.POST, url, jsonRequest,
            { response ->
                Log.d("FCM", "✅ Notification sent successfully: $response")
            },
            { error ->
                Log.e("FCM", "❌ Error sending FCM notification", error)
                if (error is ClientError) {
                    Log.e("FCM", "⚠️ Client Error: Check FCM Server Key and request format.")
                }
            }) {
            override fun getHeaders(): MutableMap<String, String> {
                return mutableMapOf(
                    "Authorization" to "key=$serverKey",
                    "Content-Type" to "application/json"
                )
            }
        }

        Volley.newRequestQueue(context).add(request)
    }
}