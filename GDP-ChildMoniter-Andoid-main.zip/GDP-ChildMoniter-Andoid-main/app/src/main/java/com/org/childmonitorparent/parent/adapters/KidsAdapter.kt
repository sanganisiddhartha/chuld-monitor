package com.org.childmonitorparent.parent.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.org.childmonitorparent.common.interfaces.OnClickPosition
import com.org.childmonitorparent.common.interfaces.OnClickType
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.databinding.KidsListItemBinding
import com.org.childmonitorparent.parent.models.ChildInfo

class KidsAdapter(
    private val onClickType: OnClickTypeValue,
    private val childList: MutableList<ChildInfo>
) :
    RecyclerView.Adapter<KidsAdapter.ChildViewHolder>() {

    inner class ChildViewHolder(private val binding: KidsListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(child: ChildInfo) {
            binding.kidName.text = "${child.name}"
            binding.lockDevice.isChecked = child.isDeviceLocked
            binding.lockDevice.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    onClickType.onClick(adapterPosition, "lock_device_true", "$isChecked")
                } else {
                    onClickType.onClick(adapterPosition, "lock_device_false", "$isChecked")
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildViewHolder {
        val binding =
            KidsListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ChildViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChildViewHolder, position: Int) {
        holder.bind(childList[position])
        holder.itemView.setOnClickListener {
            onClickType.onClick(position, "kid_details", "clicked")
        }
    }

    override fun getItemCount(): Int = childList.size
}
