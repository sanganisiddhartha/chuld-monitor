package com.org.childmonitorparent.common.utils

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.text.method.PasswordTransformationMethod
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.utils.Validators.isValidGeoFenceDiameter
import com.org.childmonitorparent.databinding.ChangePasswordDialogBinding
import com.org.childmonitorparent.databinding.ForgotPasswordDialogBinding
import com.org.childmonitorparent.databinding.GeoFenceDialogBinding
import com.org.childmonitorparent.databinding.LockDialogBinding
import com.org.childmonitorparent.databinding.LogoutDialogBinding
import java.util.*


object DialogHelper {

    fun showForgotPasswordDialog(
        context: Context,
        onChangePassword: (success: Boolean, onComplete: String) -> Unit
    ) {
        val binding = ForgotPasswordDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = AlertDialog.Builder(context)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.closeImage.setOnClickListener {
            onChangePassword(false, "")
            dialog.dismiss()
        }

        binding.resetPassword.setOnClickListener {
            val email = binding.email.text.toString().trim()
            if (email.isEmpty()) {
                Toast.makeText(context, "Please enter email", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            /*if (Validators.isValidEmail(email)) {
                Toast.makeText(context, "Please enter a valid email", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }*/

            onChangePassword(true, email)
            dialog.dismiss()
        }
        dialog.show()
    }

    fun showChangePasswordDialog(
        context: Context,
        onChangePassword: (success: Boolean, currentPassword: String, newPassword: String) -> Unit
    ) {
        val binding = ChangePasswordDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = AlertDialog.Builder(context)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.togglePassword.setOnClickListener {
            val isPasswordVisible = binding.confirmNewPassword.transformationMethod == null
            if (isPasswordVisible) {
                // Hide password
                binding.confirmNewPassword.transformationMethod =
                    PasswordTransformationMethod.getInstance()
                binding.togglePassword.setImageResource(R.drawable.ic_eye_visibility) // Change icon
            } else {
                // Show password
                binding.confirmNewPassword.transformationMethod = null
                binding.togglePassword.setImageResource(R.drawable.ic_eye_visibility_off) // Change icon
            }
            // Move cursor to the end of the text
            binding.confirmNewPassword.setSelection(binding.confirmNewPassword.text?.length ?: 0)
        }

        binding.closeImage.setOnClickListener {
            onChangePassword(false, "", "")
            dialog.dismiss()
        }

        binding.changePassword.setOnClickListener {
            val currentPassword = binding.currentPassword.text.toString().trim()
            val newPassword = binding.newPassword.text.toString().trim()
            val confirmNewPassword = binding.confirmNewPassword.text.toString().trim()
            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmNewPassword.isEmpty()
            ) {
                Toast.makeText(context, "Please enter all passwords fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!Validators.isValidPassword(newPassword)) {
                Toast.makeText(context, "Password should be at least 6 characters, one uppercase, one lowercase, one number and one special character", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (newPassword != confirmNewPassword) {
                Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            onChangePassword(true, currentPassword, confirmNewPassword)
            dialog.dismiss()
        }
        dialog.show()
    }

    fun showLogoutDialog(context: Context, onLogout: (success: Boolean) -> Unit) {
        val binding = LogoutDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = AlertDialog.Builder(context)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.btnCancelLock.setOnClickListener {
            onLogout(false)
            dialog.dismiss()
        }
        binding.btnLock.setOnClickListener {
            onLogout(true)
            dialog.dismiss()
        }
        dialog.show()
    }


    fun geoFenceDialog(context: Context, onGeoFenceSelected: (saveData: Boolean) -> Unit) {
        val binding = GeoFenceDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = AlertDialog.Builder(context)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.btnSetGeoFence.setOnClickListener {
            val selectedEntry: String = binding.spinnerGeoFenceEntries.selectedItem.toString()
            val geoFenceDiameter: String = binding.txtGeoFenceDiameter.text.toString()
            if (!isValidGeoFenceDiameter(geoFenceDiameter)) {
                binding.txtGeoFenceDiameter.error =
                    context.resources.getString(R.string.please_enter_a_valid_diameter)
                binding.txtGeoFenceDiameter.requestFocus()
            } else {

                dialog.dismiss()
            }
        }

        binding.btnCancelSetGeoFence.setOnClickListener {
            onGeoFenceSelected(false)
            dialog.dismiss()
        }
        dialog.show()
    }

    fun showLockDialog(context: Context, onLockSelected: (saveData: Boolean, Long?) -> Unit) {
        val binding = LockDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = AlertDialog.Builder(context)
            .setView(binding.root)
            .setCancelable(true)
            .create()
        var lockTime: Long? = null

        binding.spinnerLockEntries.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if (position == 0) {
                        binding.layoutLockTime.visibility = View.GONE
                        lockTime = null
                    } else {
                        binding.layoutLockTime.visibility = View.VISIBLE
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    // Do nothing
                }
            }

        binding.btnCancelLock.setOnClickListener {
            onLockSelected(false, null)
            dialog.dismiss()
        }
        binding.btnLock.setOnClickListener {
            if (binding.spinnerLockEntries.selectedItemPosition == 0) {
                onLockSelected(true, null)
            } else {
                val lockHours = binding.txtLockHours.text.toString().trim()
                val lockMinutes = binding.txtLockMinutes.text.toString().trim()
                if (lockHours
                        .isEmpty() || lockMinutes.isEmpty()
                ) {
                    Toast.makeText(context, "Please select a time!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                } else {

                    val hours = lockHours.toIntOrNull() ?: 0
                    val minutes = lockMinutes.toIntOrNull() ?: 0
                    val totalMinutes = hours * 60 + minutes
                    lockTime = System.currentTimeMillis() + (totalMinutes * 60 * 1000)
                }
                onLockSelected(true, lockTime)
            }
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun showTimePickerDialog(context: Context, onTimeSelected: (Long) -> Unit) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(context, { _, selectedHour, selectedMinute ->
            calendar.set(Calendar.HOUR_OF_DAY, selectedHour)
            calendar.set(Calendar.MINUTE, selectedMinute)
            calendar.set(Calendar.SECOND, 0)

            val lockTime = calendar.timeInMillis
            if (lockTime > System.currentTimeMillis()) {
                onTimeSelected(lockTime)
            } else {
                Toast.makeText(context, "Please select a future time!", Toast.LENGTH_SHORT).show()
            }
        }, hour, minute, true).show()
    }
}