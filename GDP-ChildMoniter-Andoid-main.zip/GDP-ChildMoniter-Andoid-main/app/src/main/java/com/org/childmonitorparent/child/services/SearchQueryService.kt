package com.org.childmonitorparent.child.services

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.org.childmonitorparent.child.models.SearchLogs
import com.org.childmonitorparent.common.utils.PrefsHelper

class SearchQueryService : AccessibilityService() {
    private val db = FirebaseFirestore.getInstance()
    private val handler = Handler(Looper.getMainLooper()) // For delayed logging
    private var lastQuery: String? = null // Store last detected query
    private var queryRunnable: Runnable? = null // Runnable to delay logging
    private var searchQueryList = mutableListOf<String>()
    private var blockedKeywords = mutableListOf<String>()
    private val childId = PrefsHelper.getData("userId")

    override fun onServiceConnected() {
        super.onServiceConnected()
        getBlockedKeywords() // 🔥 Fetch blocked words once at startup
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED || event?.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED || event?.eventType == AccessibilityEvent.TYPE_VIEW_CONTEXT_CLICKED || event?.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED || event?.eventType == AccessibilityEvent.TYPE_VIEW_HOVER_ENTER) {
            var query = event.text?.toString()?.trim() ?: return
            query = query.replace(Regex("[^a-zA-Z0-9 ]"), "")

            /*// If user is still typing, cancel the previous log request
            queryRunnable?.let {
                handler.removeCallbacks(it)
            }

            // Schedule a new log request after 1.5 seconds of inactivity
            queryRunnable = Runnable {
                if (query.isNotBlank() && query != lastQuery) {
                    lastQuery = query
                    if (blockedKeywords.any { query.contains(it, ignoreCase = true) })
                        closeSearchBrowser()
                    else logSearchQuery(query) // 🔥 Save to Firestore
                }
            }
            handler.postDelayed(queryRunnable!!, 2000) // 2 sec delay
            */
        }
    }

    private fun closeSearchBrowser() {
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.killBackgroundProcesses("com.android.chrome") // Kill Chrome process
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    private fun getBlockedKeywords() {
        val blockedKeywordsRef = db.collection("blocked_keyword").document(childId)

        blockedKeywordsRef.addSnapshotListener { documentSnapshot, error ->
            if (error != null) {
                Log.e("Firestore", "Error listening for updates", error)
                return@addSnapshotListener
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                val blockedKeywordList =
                    documentSnapshot.get("blockedKeyword") as? List<String> ?: emptyList()
                blockedKeywords.addAll(blockedKeywordList) // 🔥 Live update in ViewModel
                Log.d("Firestore", "Blocked keyword Updated: $blockedKeywordList")
            } else {
                Log.d("Firestore", "No blocked keyword found")
                blockedKeywords = mutableListOf()
            }
        }
    }

    private fun logSearchQuery(query: String) {
        if (!searchQueryList.contains(query))
            searchQueryList.add(query)
        val searchLog = mapOf(
            "queryLogs" to searchQueryList
        )
        val searchLogsRef = db.collection("search_logs")
            .document(childId)

        searchLogsRef.set(searchLog, SetOptions.merge())
            .addOnSuccessListener {
                println("Search query logged successfully")
            }
            .addOnFailureListener { e ->
                println("Error logging search query: ${e.message}")
            }
    }

    override fun onInterrupt() {}
}
