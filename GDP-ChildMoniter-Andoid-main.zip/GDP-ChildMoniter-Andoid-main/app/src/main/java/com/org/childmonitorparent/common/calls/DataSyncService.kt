package com.org.childmonitorparent.common.calls

import android.app.*
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.location.Geocoder
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.firestore.FirebaseFirestore
import com.org.childmonitorparent.R
import com.org.childmonitorparent.child.broadcast_receivers.StartServicesReceiver
import com.org.childmonitorparent.child.broadcast_receivers.SyncDeviceReceiver
import com.org.childmonitorparent.common.utils.NotificationUtils
import com.org.childmonitorparent.common.utils.PrefsHelper
import java.util.Locale

class DataSyncService : Service() {

    private val db = FirebaseFirestore.getInstance()
    private lateinit var receiver: SyncDeviceReceiver
    private var isCallActive = false  // ✅ Prevent duplicate call UI

    override fun onCreate() {
        super.onCreate()
        val notification = createNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(2, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(2, notification)
        }
        registerReceiver()
    }

    private fun registerReceiver() {
        receiver = SyncDeviceReceiver()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
            addAction(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)
        }
        registerReceiver(receiver, filter)
    }

    private fun createNotification(): Notification {
        val channelId = "notification_channel"
        val channelName = "Notifications"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel =
                NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Service Running")
            .setContentText("Listening for data...")
            .setOngoing(true)
            .build()
        return notification
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        listenForCalls()
        listenForChildLocation()
        listenForSOSAlerts()
        listenForChatNotifications()
        return START_STICKY
    }

    private fun listenForChatNotifications() {
        db.collection("chat_notifications")
            .addSnapshotListener { snapshot, _ ->
                snapshot?.documents?.forEach { document ->
                    val isShowNotification =
                        document.getBoolean("isShowNotification") ?: return@forEach
                    val senderName = document.getString("senderName") ?: return@forEach
                    val receiverId = document.getString("receiverId") ?: return@forEach
                    var message = document.getString("message") ?: return@forEach
                    val timestamp = document.getLong("timestamp") ?: return@forEach

                    var notificationType = ""
                    if (message.isEmpty())
                        message = "$senderName sent you a file"
                    notificationType = if (PrefsHelper.getData("userType") == "Parent")
                        "parent"
                    else "child"

                    if (receiverId == PrefsHelper.getData("userId") && isShowNotification) {
                        NotificationUtils.showPushNotification(
                            this,
                            "$senderName sent you a message!",
                            message,
                            notificationType
                        )
                        updateChatNotification(document.id)
                    }
                }
            }
    }

    private fun updateChatNotification(id: String) {
        val sosAlertRef = db.collection("chat_notifications").document(id)
        sosAlertRef.update("isShowNotification", false)
            .addOnSuccessListener {
                println("✅ Chat notification updated")
            }
            .addOnFailureListener { e ->
                println("❌ Failed to update chat notification: ${e.message}")
            }
    }

    private fun listenForSOSAlerts() {
        db.collection("sos_alerts")
            .addSnapshotListener { snapshot, _ ->
                snapshot?.documents?.forEach { document ->
                    val message = document.getString("message") ?: return@forEach
                    val userName = document.getString("userName") ?: return@forEach
                    val receiverId = document.getString("receiverId") ?: return@forEach
                    val isShowAlert = document.getString("isShowAlert") ?: return@forEach

                    if (receiverId == PrefsHelper.getData("userId") && isShowAlert == "true") {
                        NotificationUtils.showPushNotification(
                            this,
                            "$userName is in Emergency!",
                            message,
                            "parent",
                        )
                        updateSOSAlerts(document.id)
                    }
                }
            }
    }

    private fun updateSOSAlerts(id: String) {
        val sosAlertRef = db.collection("sos_alerts").document(id)
        sosAlertRef.update("isShowAlert", "false")
            .addOnSuccessListener {
                println("✅ SOS alert updated")
            }
            .addOnFailureListener { e ->
                println("❌ Failed to update SOS alert: ${e.message}")
            }
    }

    private fun listenForChildLocation() {
        db.collection("locations")
            .whereEqualTo("parentId", PrefsHelper.getData("userId"))
            .addSnapshotListener { snapshot, _ ->
                snapshot?.let { querySnapshot ->
                    for (document in querySnapshot.documents) {
                        val childName = document.getString("childName")
                        val latitude = document.getDouble("latitude")
                        val longitude = document.getDouble("longitude")
                        val outside = document.getBoolean("outside")
                        val parentId = document.getString("parentId")

                        val address = getAddressFromLatLng(LatLng(latitude!!, longitude!!))

                        if (parentId == PrefsHelper.getData("userId") && outside == true) { // ✅ Ensure it's for this user
                            NotificationUtils.showPushNotification(
                                this@DataSyncService,
                                "$childName Left Safe Zone",
                                "Your child $childName is at $address", "parent"
                            )
                        }
                    }
                }
            }
    }

    private fun listenForCalls() {
        db.collection("calls")
            .whereEqualTo("receiverId", PrefsHelper.getData("userId"))
            .addSnapshotListener { snapshot, _ ->
                snapshot?.let { querySnapshot ->
                    for (document in querySnapshot.documents) {
                        val callerName = document.getString("callerName")
                        val receiverId = document.getString("receiverId")
                        val roomId = document.getString("roomId")
                        val status = document.getString("status")

                        if (receiverId == PrefsHelper.getData("userId") && status == "active") { // ✅ Ensure it's for this user
                            if (!isCallActive) { // ✅ Prevent duplicate UI launches
                                isCallActive = true
                                handleIncomingCall(callerName, roomId, receiverId)
                            }
                        }
                    }
                }
            }
    }

    private fun handleIncomingCall(callerName: String?, roomId: String?, receiverId: String?) {
        if (receiverId == PrefsHelper.getData("userId")) {
            showIncomingCallNotification(callerName, roomId, receiverId)
            launchIncomingCallUI(callerName, roomId, receiverId)
        }
    }

    private fun launchIncomingCallUI(callerName: String?, roomId: String?, receiverId: String?) {
        val intent = Intent(this, IncomingCallActivity::class.java).apply {
            putExtra("callerName", callerName)
            putExtra("roomId", roomId)
            putExtra("receiverId", receiverId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        this.startActivity(intent)
    }

    private fun showIncomingCallNotification(
        callerName: String?,
        roomId: String?,
        receiverId: String?
    ) {
        val intent = Intent(this, IncomingCallActivity::class.java).apply {
            putExtra("callerName", callerName)
            putExtra("roomId", roomId)
            putExtra("receiverId", receiverId)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, "call_channel")
            .setContentTitle("Incoming Call")
            .setContentText("$callerName is calling...")
            .setSmallIcon(R.drawable.ic_call)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(2, notification) // Show the incoming call notification
    }

    private fun getAddressFromLatLng(latLng: LatLng): String {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
        return if (addresses!!.isNotEmpty()) {
            addresses[0].getAddressLine(0) ?: "Unknown Address"
        } else {
            "Unknown Address"
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        val intent = Intent(this, StartServicesReceiver::class.java).apply {
            action = "NotificationServiceDestroyed"
        }
        sendBroadcast(intent)
    }
}