package com.org.childmonitorparent.child.fragments

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.org.childmonitorparent.child.adapters.PermissionAdapter
import com.org.childmonitorparent.child.models.PermissionItem
import com.org.childmonitorparent.child.services.LocationService
import com.org.childmonitorparent.child.viewmodels.ActivityLogViewModel
import com.org.childmonitorparent.child.viewmodels.PermissionsViewModel
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.common.utils.PermissionDiffCallback
import com.org.childmonitorparent.common.utils.PermissionsHelper
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.viewmodels.AppsViewModel
import com.org.childmonitorparent.common.viewmodels.LogsViewModel
import com.org.childmonitorparent.databinding.FragmentPermissionListBinding
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import com.org.childmonitorparent.child.broadcast_receivers.DeviceAdminReceivers
import com.org.childmonitorparent.child.services.AppsAccessibilityService
import com.org.childmonitorparent.common.utils.ServiceHelper
import com.org.childmonitorparent.common.utils.isAccessibilityServiceEnabled

class PermissionListFragment : Fragment(), OnClickTypeValue {

    private var _binding: FragmentPermissionListBinding? = null
    private val binding get() = _binding!!
    private val logsViewModel: LogsViewModel by activityViewModels()
    private val activityLogViewModel: ActivityLogViewModel by activityViewModels()
    private val permissionsViewModel: PermissionsViewModel by activityViewModels()
    private lateinit var permissionAdapter: PermissionAdapter
    private lateinit var context: Context
    private val childId = PrefsHelper.getData("userId")
    private var itemPosition = 0
    private val permissionCollection: MutableList<PermissionItem> = mutableListOf(
        PermissionItem(Manifest.permission.ACCESS_FINE_LOCATION, "Enable Location Access", false),
        PermissionItem(Manifest.permission.READ_CALL_LOG, "Allow Call Log Access", false),
        PermissionItem(Manifest.permission.READ_CONTACTS, "Allow Contacts Access", false),
        PermissionItem(Manifest.permission.READ_SMS, "Allow SMS Access", false),
        PermissionItem("Share Apps", "Share Apps with Parent", false),
        PermissionItem("Device Lock", "Enable Device Lock Service", false),
        /*PermissionItem("Manifest.permission.POST_NOTIFICATIONS", "Enable Notification", false)*/
    )

    // ✅ Corrected: Convert `permissionCollection` to an `ArrayList`
    private val permissionList: ArrayList<PermissionItem> = ArrayList(permissionCollection)
    private lateinit var locationServiceIntent: Intent

    companion object {
        private const val REQUEST_CODE_LOCATION = 1
    }

    private val requestLocationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val fineLocationGranted =
                permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
            val coarseLocationGranted =
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

            if (fineLocationGranted || coarseLocationGranted) {
                println("✅ Location permission granted")
                ServiceHelper.startLocationService(context, locationServiceIntent)
            } else {
                println("❌ Location permission denied")
                if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    showSettingsDialog("Location")
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Location permission is required!",
                        Toast.LENGTH_SHORT
                    ).show()
                    ActivityCompat.requestPermissions(
                        requireActivity(),
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        ),
                        REQUEST_CODE_LOCATION
                    )
                }
            }
        }
    private val requestCallLogPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                println("✅ Call Log permission granted")
                permissionList[itemPosition].isGranted = true
                permissionsViewModel.saveChildPermissions(childId, permissionList)
                activityLogViewModel.fetchCallLogs(context)
            } else {
                println("❌ Call Log permission denied")
                permissionList[itemPosition].isGranted = false
                permissionsViewModel.saveChildPermissions(childId, permissionList)
                showSettingsDialog("Call Log")
                Toast.makeText(
                    requireContext(),
                    "Call Log permission is required!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    private val requestContactsPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                println("✅ Contacts permission granted")
                permissionList[itemPosition].isGranted = true
                permissionsViewModel.saveChildPermissions(childId, permissionList)
                activityLogViewModel.fetchContactLogs(context)
            } else {
                println("❌ Contacts permission denied")
                permissionList[itemPosition].isGranted = false
                permissionsViewModel.saveChildPermissions(childId, permissionList)
                showSettingsDialog("Contacts")
                Toast.makeText(
                    requireContext(),
                    "Contacts permission is required!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    private val requestSmsPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                println("✅ SMS permission granted")
                permissionList[itemPosition].isGranted = true
                permissionsViewModel.saveChildPermissions(childId, permissionList)
                activityLogViewModel.fetchMessageLogs(context)
            } else {
                println("❌ SMS permission denied")
                permissionList[itemPosition].isGranted = false
                permissionsViewModel.saveChildPermissions(childId, permissionList)
                showSettingsDialog("SMS")
                Toast.makeText(
                    requireContext(),
                    "SMS permission is required!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                println("✅ Notification permission granted")
                permissionList[itemPosition].isGranted = true
                permissionsViewModel.saveChildPermissions(childId, permissionList)
            } else {
                println("❌ Notification permission denied")
                permissionList[itemPosition].isGranted = false
                permissionsViewModel.saveChildPermissions(childId, permissionList)
                showSettingsDialog("Notification")
                Toast.makeText(
                    requireContext(),
                    "Notification permission is required!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentPermissionListBinding.inflate(inflater, container, false)
        context = requireContext()

        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        locationServiceIntent = Intent(requireContext(), LocationService::class.java)

        setUpObservers()
        permissionsViewModel.getChildPermissions(childId)
        showPermissionsList()
    }

    private fun checkAccessibilityPermission(context: Context) {
        if (isAccessibilityServiceEnabled(context, AppsAccessibilityService::class.java)) {
            permissionList[itemPosition].isGranted = true
            ServiceHelper.startBlockAppsService(context)
            getChildApps()
        } else {
            requestAccessibilityPermission(context)
        }
    }

    private fun requestAccessibilityPermission(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
    }

    private fun requestUsageStatsPermission() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        startActivity(intent)
    }

    private fun isUsageAccessGranted(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun getChildApps() {
        val appsViewModel = AppsViewModel(context)
        val appsList = appsViewModel.getUserInstalledApps(context)
        appsViewModel.saveChildApps(childId, appsList)
    }

    private fun updatePermissionList(newList: List<PermissionItem>) {
        val diffCallback = PermissionDiffCallback(permissionList, newList)
        val diffResult = DiffUtil.calculateDiff(diffCallback)

        permissionList.clear()
        permissionList.addAll(newList)
        diffResult.dispatchUpdatesTo(permissionAdapter)
    }

    private fun checkPermissions() {
        val updatedList = permissionList.map { permissionItem ->
            when (permissionItem.permission) {
                Manifest.permission.ACCESS_FINE_LOCATION -> {
                    if (PermissionsHelper.hasLocationPermission(context))
                        ServiceHelper.startLocationService(context, locationServiceIntent)
                    permissionItem.copy(isGranted = PermissionsHelper.hasLocationPermission(context))
                }

                Manifest.permission.READ_CALL_LOG -> {
                    if (PermissionsHelper.hasCallLogPermission(context))
                        activityLogViewModel.fetchCallLogs(context)
                    permissionItem.copy(isGranted = PermissionsHelper.hasCallLogPermission(context))
                }

                Manifest.permission.READ_CONTACTS -> {
                    if (PermissionsHelper.hasReadContactsPermission(context))
                        activityLogViewModel.fetchContactLogs(context)
                    permissionItem.copy(
                        isGranted = PermissionsHelper.hasReadContactsPermission(
                            context
                        )
                    )
                }

                Manifest.permission.READ_SMS -> {
                    if (PermissionsHelper.hasReadSMSPermission(context))
                        activityLogViewModel.fetchMessageLogs(context)

                    permissionItem.copy(isGranted = PermissionsHelper.hasReadSMSPermission(context))
                }

                "Share Apps" -> {
                    if (isAccessibilityServiceEnabled(
                            context,
                            AppsAccessibilityService::class.java
                        )
                    ) {
                        ServiceHelper.startBlockAppsService(context)
                        getChildApps()
                    }
                    permissionItem.copy(
                        isGranted = isAccessibilityServiceEnabled(
                            context,
                            AppsAccessibilityService::class.java
                        )
                    )
                }

                "Device Lock" -> {
                    if (PermissionsHelper.isDeviceAdminEnabled(
                            context,
                            DeviceAdminReceivers::class.java
                        )
                    ) ServiceHelper.startDeviceLockService(context)

                    permissionItem.copy(
                        isGranted = PermissionsHelper.isDeviceAdminEnabled(
                            context,
                            DeviceAdminReceivers::class.java
                        )
                    )
                }

                "Manifest.permission.POST_NOTIFICATIONS" -> {
                    permissionItem.copy(
                        isGranted = PermissionsHelper.hasNotificationPermission(context)
                    )
                }

                else -> permissionItem
            }
        }

        permissionsViewModel.saveChildPermissions(childId, updatedList)
        updatePermissionList(updatedList)
    }

    private fun setUpObservers() {
        permissionsViewModel.childPermissions.observe(viewLifecycleOwner) { permissions ->
            permissions?.let {
                if (it.isNotEmpty()) {
                    updatePermissionList(it)
                }
            }
        }
        activityLogViewModel.callLogs.observe(viewLifecycleOwner) { logs ->
            logsViewModel.saveCallLogs(childId, logs)
        }
        activityLogViewModel.messageLogs.observe(viewLifecycleOwner) { logs ->
            logsViewModel.saveMessageLogs(childId, logs)
        }
        activityLogViewModel.contactLogs.observe(viewLifecycleOwner) { logs ->
            logsViewModel.saveContactLogs(childId, logs)
        }
    }

    private fun showPermissionsList() {
        binding.permissionsList.layoutManager = LinearLayoutManager(context)
        permissionAdapter = PermissionAdapter(permissionList, this)
        binding.permissionsList.adapter = permissionAdapter
    }

    private fun requestPermission(permissionItem: PermissionItem, value: String) {
        when (permissionItem.permission) {
            Manifest.permission.ACCESS_FINE_LOCATION -> {
                if (value == "true") {
                    if (ContextCompat.checkSelfPermission(context, permissionItem.permission)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        requestLocationPermission()
                    } else {
                        println("Location permission granted")
                        permissionList[itemPosition].isGranted = true
                        permissionsViewModel.saveChildPermissions(childId, permissionList)
                        ServiceHelper.startLocationService(context, locationServiceIntent)
                    }
                } else {
                    permissionList[itemPosition].isGranted = false
                    permissionsViewModel.saveChildPermissions(childId, permissionList)
                    ServiceHelper.stopLocationService(context, locationServiceIntent)
                }
            }

            Manifest.permission.READ_CALL_LOG -> {
                if (value == "true") {
                    if (ContextCompat.checkSelfPermission(context, permissionItem.permission)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        /*ActivityCompat.requestPermissions(
                        requireActivity(),
                        arrayOf(Manifest.permission.READ_CALL_LOG),
                        REQUEST_CODE_CALL_LOG
                    )*/
                        requestCallLogPermissionLauncher.launch(Manifest.permission.READ_CALL_LOG)
                    } else {
                        permissionList[itemPosition].isGranted = true
                        permissionsViewModel.saveChildPermissions(childId, permissionList)
                        activityLogViewModel.fetchCallLogs(context)
                    }
                } else {
                    permissionList[itemPosition].isGranted = false
                    permissionsViewModel.saveChildPermissions(childId, permissionList)
                }
            }

            Manifest.permission.READ_CONTACTS -> {
                if (value == "true") {
                    if (ContextCompat.checkSelfPermission(context, permissionItem.permission)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        /*ActivityCompat.requestPermissions(
                        requireActivity(),
                        arrayOf(Manifest.permission.READ_CONTACTS),
                        REQUEST_CODE_CONTACTS
                    )*/
                        requestContactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                    } else {
                        permissionList[itemPosition].isGranted = true
                        permissionsViewModel.saveChildPermissions(childId, permissionList)
                        activityLogViewModel.fetchContactLogs(context)
                    }
                } else {
                    permissionList[itemPosition].isGranted = false
                    permissionsViewModel.saveChildPermissions(childId, permissionList)
                }
            }

            Manifest.permission.READ_SMS -> {
                if (value == "true") {
                    if (ContextCompat.checkSelfPermission(context, permissionItem.permission)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        /*ActivityCompat.requestPermissions(
                        requireActivity(),
                        arrayOf(Manifest.permission.READ_SMS),
                        REQUEST_CODE_SMS
                    )*/
                        requestSmsPermissionLauncher.launch(Manifest.permission.READ_SMS)
                    } else {
                        permissionList[itemPosition].isGranted = true
                        permissionsViewModel.saveChildPermissions(childId, permissionList)
                        activityLogViewModel.fetchMessageLogs(context)
                    }
                } else {
                    permissionList[itemPosition].isGranted = false
                    permissionsViewModel.saveChildPermissions(childId, permissionList)
                }

            }

            "Share Apps" -> {
                println("Requesting share apps permission")
                if (value == "true") {
                    permissionList[itemPosition].isGranted = true
                    checkAccessibilityPermission(context)
                    if (!isUsageAccessGranted())
                        requestUsageStatsPermission()
                } else permissionList[itemPosition].isGranted = false

                permissionsViewModel.saveChildPermissions(childId, permissionList)
            }

            "Device Lock" -> {
                if (value == "true") {
                    PermissionsHelper.requestDeviceAdmin(context)
                } else {
                    permissionList[itemPosition].isGranted = false
                    permissionsViewModel.saveChildPermissions(childId, permissionList)
                }
            }

            "Manifest.permission.POST_NOTIFICATIONS" -> {
                if (value == "true") {
                    if (ContextCompat.checkSelfPermission(context, permissionItem.permission)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    } else {
                        permissionList[itemPosition].isGranted = true
                        permissionsViewModel.saveChildPermissions(childId, permissionList)
                    }
                } else {
                    permissionList[itemPosition].isGranted = false
                    permissionsViewModel.saveChildPermissions(childId, permissionList)
                }
            }
        }
    }

    private fun requestLocationPermission() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            == PackageManager.PERMISSION_GRANTED
        ) {
            println("✅ Location permission already granted.")
            ServiceHelper.startLocationService(context, locationServiceIntent)
            return
        }

        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            permissions.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }

        println("🔹 Requesting location permissions: $permissions")
        requestLocationPermissionLauncher.launch(permissions.toTypedArray())
    }

    private fun showSettingsDialog(permissionType: String) {
        AlertDialog.Builder(requireContext())
            .setTitle("Permission Required")
            .setMessage("$permissionType permission is required. Please enable it in Settings.")
            .setPositiveButton("Go to Settings") { _, _ ->
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", requireContext().packageName, null)
                intent.data = uri
                startActivity(intent)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onClick(position: Int, type: String, value: String) {
        itemPosition = position
        requestPermission(permissionList[position], value)
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}