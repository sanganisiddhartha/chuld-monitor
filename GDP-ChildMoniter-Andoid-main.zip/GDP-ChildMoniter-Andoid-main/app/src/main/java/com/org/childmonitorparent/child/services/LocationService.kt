package com.org.childmonitorparent.child.services

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import com.org.childmonitorparent.child.broadcast_receivers.StartServicesReceiver
import com.org.childmonitorparent.parent.models.LocationData
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.parent.models.ChildInfo
import com.org.childmonitorparent.common.utils.NotificationUtils.createNotification
import com.org.childmonitorparent.common.utils.NotifyParentNotification

class LocationService : Service() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val db = Firebase.firestore
    // 🔥 Define Home & School Coordinates
    private var homeLocation = Pair(28.7041, 77.1025) // Example: Delhi, India
    private var schoolLocation = Pair(28.7091, 77.1035) // Example: Nearby school
    private var parentId = ""
    private var childName = ""

    override fun onCreate() {
        super.onCreate()
        // 🔹 Call startForeground() immediately to avoid RemoteServiceException
        val notification = createNotification(this, "Child Location Service", "Tracking location in real-time")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        getChildInfo()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startLocationUpdates()
        return START_STICKY
    }

    private fun getChildInfo() {
        db.collection("children").whereEqualTo("childId", PrefsHelper.getData("userId")).get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    return@addOnSuccessListener
                }
                val child = documents.first().toObject(ChildInfo::class.java)
                parentId = child.parentId
                childName = child.name
                val homeLat = child.homeLocation.split(",")[0].toDouble()
                val homeLong = child.homeLocation.split(",")[1].toDouble()
                val schoolLat = child.schoolLocation.split(",")[0].toDouble()
                val schoolLong = child.schoolLocation.split(",")[1].toDouble()
                homeLocation = Pair(homeLat, homeLong)
                schoolLocation = Pair(schoolLat, schoolLong)
            }
            .addOnFailureListener { e ->
                e.printStackTrace()
            }
    }

    private fun startLocationUpdates() {
        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000*60) // Every 5 sec
            .setMinUpdateIntervalMillis(1000*60) // Minimum update every 2 sec
            .build()

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            for (location in locationResult.locations) {
                // 🔥 Check if the child is outside home or school
                if (!NotifyParentNotification.isWithinLocation(location.latitude, location.longitude, homeLocation) &&
                    !NotifyParentNotification.isWithinLocation(location.latitude, location.longitude, schoolLocation)) {
                    //NotifyParentNotification.notifyParent(this@LocationService, parentId, location.latitude, location.longitude)
                    saveChildLocation(PrefsHelper.getData("userId"), location, true)
                }else{
                    saveChildLocation(PrefsHelper.getData("userId"), location, false)
                }
            }
        }
    }

    private fun saveChildLocation(childId: String, location: Location, isOutside: Boolean) {
        val locationData = LocationData(location.latitude, location.longitude, System.currentTimeMillis(), childName, childId, parentId, isOutside)
        db.collection("locations").document(childId)
            .set(locationData)
            .addOnSuccessListener { println("✅ Location saved successfully!") }
            .addOnFailureListener { e -> println("❌ Failed to save location: ${e.message}") }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        fusedLocationClient.removeLocationUpdates(locationCallback)
        val intent = Intent(this, StartServicesReceiver::class.java).apply {
            action = "LocationServiceDestroyed"
        }
        sendBroadcast(intent)
    }

    companion object {
        private const val NOTIFICATION_ID = 1
    }
}
