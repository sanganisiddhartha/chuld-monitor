package com.org.childmonitorparent.common.utils

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import com.org.childmonitorparent.R
import com.org.childmonitorparent.databinding.DialogProgressBinding

object ProgressDialogHelper {
    private var progressDialog: AlertDialog? = null

    fun showProgressDialog(context: Context, message: String = "Loading...") {
        if (progressDialog != null && progressDialog!!.isShowing) return

        val builder = AlertDialog.Builder(context, R.style.TransparentDialogTheme)
        val binding = DialogProgressBinding.inflate(LayoutInflater.from(context))
        builder.setView(binding.root) // Create a custom layout
        builder.setCancelable(false)

        binding.progressText.text = message

        progressDialog = builder.create()
        progressDialog?.show()
    }

    fun hideProgressDialog() {
        progressDialog?.dismiss()
        progressDialog = null
    }
}
