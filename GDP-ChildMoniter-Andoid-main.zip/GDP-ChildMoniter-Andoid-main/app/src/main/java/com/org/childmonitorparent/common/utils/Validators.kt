package com.org.childmonitorparent.common.utils

import android.app.Activity
import android.content.Context
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Uri
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.firebase.auth.FirebaseUser

object Validators {
    fun isValidEmail(email: String): Boolean {
        val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"

        if (email == "") {
            return false
        }
        return email.trim { it <= ' ' }.matches(emailPattern.toRegex())
    }

    fun isValidPassword(password: String): Boolean {
        if (password == "") return false
        if (password.length < 6)
            return false
        val passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#\$%^&+=!]).{6,}$"
        return password.matches(passwordPattern.toRegex())
    }

    fun isValidHours(hours: String): Boolean {
        if (hours == "") {
            return false
        }

        return hours.length <= 23
    }

    fun isValidMinutes(minutes: String): Boolean {
        if (minutes == "") {
            return false
        }

        return minutes.length <= 59
    }

    fun isValidGeoFenceDiameter(diameter: String): Boolean {
        return diameter != ""
    }


    fun isValidName(name: String): Boolean {
        return name.length <= 15 && name != ""
    }

    fun isValidImageURI(imageUri: Uri?): Boolean {
        return imageUri != null
    }

    fun isVerified(user: FirebaseUser): Boolean {
        return user.isEmailVerified
    }

    fun isInternetAvailable(context: Context): Boolean {
        var haveConnectedWifi = false
        var haveConnectedMobile = false

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.allNetworkInfo
        for (ni in netInfo) {
            if (ni.typeName.equals(
                    "WIFI",
                    ignoreCase = true
                )
            ) if (ni.isConnected) haveConnectedWifi = true
            if (ni.typeName.equals(
                    "MOBILE",
                    ignoreCase = true
                )
            ) if (ni.isConnected) haveConnectedMobile = true
        }
        return haveConnectedWifi || haveConnectedMobile
    }

    fun isGooglePlayServicesAvailable(activity: Activity): Boolean {
        val googleApiAvailability = GoogleApiAvailability.getInstance()
        val status = googleApiAvailability.isGooglePlayServicesAvailable(activity)
        if (status != ConnectionResult.SUCCESS) {
            if (googleApiAvailability.isUserResolvableError(status)) googleApiAvailability.getErrorDialog(
                activity,
                status,
                2404
            )!!
                .show()
            return false
        }

        return true
    }

    fun isLocationOn(context: Context): Boolean {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }
}
