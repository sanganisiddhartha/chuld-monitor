package com.org.childmonitorparent.common.calls

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.facebook.react.modules.core.PermissionListener
import com.org.childmonitorparent.databinding.ActivityIncomingCallBinding
import org.jitsi.meet.sdk.JitsiMeetActivity
import org.jitsi.meet.sdk.JitsiMeetActivityInterface
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions
import java.net.URL

class IncomingCallActivity : AppCompatActivity(), JitsiMeetActivityInterface {

    private lateinit var binding: ActivityIncomingCallBinding
    private lateinit var roomId: String
    private lateinit var callerName: String
    private lateinit var receiverId: String
    private val callViewModel: CallViewModel by viewModels()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIncomingCallBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get the room ID and caller name from the intent
        roomId = intent.getStringExtra("roomId") ?: ""
        callerName = intent.getStringExtra("callerName") ?: ""
        receiverId = intent.getStringExtra("receiverId") ?: ""

        binding.tvCallerName.text = callerName

        binding.btnPickup.setOnClickListener {
            joinIncomingCall(roomId)
            callViewModel.saveCall(roomId, "active", callerName, receiverId)
        }
        binding.btnEndCall.setOnClickListener {
            JitsiCallManager.endCall()
            callViewModel.saveCall(roomId, "ended", callerName, receiverId)
            finish()
        }

        // Dismiss after 30 seconds if not answered
        handler.postDelayed({ finish() }, 30000)
    }

    private fun joinIncomingCall(roomId: String) {
        val options = JitsiMeetConferenceOptions.Builder()
            .setServerURL(URL("https://meet.jit.si"))  // Your Jitsi server
            .setRoom(roomId)
            .setAudioOnly(true)  // Enable voice-only call
            .setAudioMuted(false)
            .setVideoMuted(true)
            .setFeatureFlag("pip.enabled", false)
            .setFeatureFlag("welcomepage.enabled", false)  // Skip welcome page
            .build()

        JitsiMeetActivity.launch(this, options)
        binding.callPickUpLayout.visibility = View.GONE
    }

    override fun requestPermissions(p0: Array<out String>?, p1: Int, p2: PermissionListener?) {
        TODO("Not yet implemented")
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null) // Prevent memory leaks
    }
}