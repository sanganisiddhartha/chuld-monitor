package com.org.childmonitorparent.common.models

data class AppsInfo (
    val appIcon: String,
    val appName: String = "",
    val packageName: String = ""
){
    constructor() : this("", "", "")
}