package com.org.childmonitorparent.child.fragments

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.org.childmonitorparent.R
import com.org.childmonitorparent.child.viewmodels.SearchLogsViewModel
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.databinding.FragmentAppsBinding
import com.org.childmonitorparent.databinding.FragmentSafeSearchBinding

class SafeSearchFragment : Fragment() {

    private var _binding: FragmentSafeSearchBinding? = null
    private val binding get() = _binding!!
    private val searchLogsViewModel: SearchLogsViewModel by activityViewModels()
    private var blockedKeywords = mutableListOf<String>()
    private val childId = PrefsHelper.getData("userId")
    private lateinit var context: Context

    // ✅ Custom User-Agent (Prevents Google from Blocking WebView)
    private val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentSafeSearchBinding.inflate(layoutInflater, container, false)
        context = requireContext()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        searchLogsViewModel.blockedKeywords.observe(viewLifecycleOwner) {
            blockedKeywords.clear()
            if (!it.isNullOrEmpty()) {
                blockedKeywords.addAll(it)
                Log.d("SafeSearch", "Blocked Keywords Updated: $blockedKeywords")

                // ✅ Immediately check if the current page should be blocked
                val currentUrl = binding.webView.url
                val currentQuery = Uri.parse(currentUrl).getQueryParameter("q") ?: ""
                if (currentQuery.isNotEmpty() && isBlocked(currentQuery)) {
                    restrictSearchImmediately() // ⛔ Stop WebView Immediately
                }
            }
        }
        searchLogsViewModel.listenForBlockedKeywords(childId)

        setupWebView()
    }

    private fun restrictSearchImmediately() {
        Log.d("SafeSearch", "🔴 Blocking Current Search Immediately")
        // Stop WebView Navigation
        binding.webView.stopLoading()
        binding.webView.loadUrl("https://www.google.com/search?q=") // Load a blank page

        // Show a Restricted Message
        Toast.makeText(requireContext(), "Access Restricted!", Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("SetJavaScriptEnabled", "NewApi")
    private fun setupWebView() {
        binding.webView.settings.apply {
            javaScriptEnabled = true  // Enable JavaScript for Google Search
            domStorageEnabled = true  // Enable local storage
            safeBrowsingEnabled = true
            userAgentString = USER_AGENT // 🔥 Prevents Google from blocking WebView searches
        }

        binding.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                Log.d("SafeSearch", "Navigating to: $url")

                // ✅ Extract Search Query
                val query = Uri.parse(url).getQueryParameter("q") ?: Uri.parse(url).getQueryParameter("p")
                query?.let {
                    Log.d("SafeSearch", "Extracted Query: $it")

                    /*// ✅ Dynamically Check Against Updated Blocked Keywords
                    if (blockedKeywords.any { keyword -> it.contains(keyword, ignoreCase = true) }) {
                        Toast.makeText(view.context, "Access Restricted!", Toast.LENGTH_SHORT).show()
                        return true // ⛔ Block search
                    }*/

                    if (isBlocked(it)) {
                        restrictSearchImmediately()
                        return true // ⛔ Block navigation
                    }

                    searchLogsViewModel.logSearchQuery(childId, it)
                    val googleSearchUrl = "https://www.google.com/search?q=$it"
                    view.loadUrl(googleSearchUrl) // ✅ Continue with SafeSearch
                }

                return false // ✅ Allow navigation if not blocked
            }
        }

        // ✅ Load Google Search with SafeSearch Enabled
        binding.webView.loadUrl("https://www.google.com/search?q=")
    }

    private fun isBlocked(query: String): Boolean {
        return blockedKeywords.any { keyword -> query.contains(keyword, ignoreCase = true) }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}