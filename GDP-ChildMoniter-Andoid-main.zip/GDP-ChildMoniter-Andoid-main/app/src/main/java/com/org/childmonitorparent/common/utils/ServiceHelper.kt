package com.org.childmonitorparent.common.utils

import android.content.Context
import android.content.Intent
import android.os.Build
import com.org.childmonitorparent.child.services.BlockAppsService
import com.org.childmonitorparent.child.services.DeviceLockService
import com.org.childmonitorparent.common.calls.DataSyncService

object ServiceHelper {

    fun startLocationService(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent) // Required for Android 8+
        } else {
            context.startService(intent)
        }
    }

    fun stopLocationService(context: Context, intent: Intent) {
        context.stopService(intent)
    }

    fun startDeviceLockService(context: Context) {
        val serviceIntent = Intent(context, DeviceLockService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent) // Required for Android 8+
        } else {
            context.startService(serviceIntent)
        }
    }

    fun startBlockAppsService(context: Context) {
        val serviceIntent = Intent(context, BlockAppsService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent) // Required for Android 8+
        } else {
            context.startService(serviceIntent)
        }
    }

    fun startCallService(context: Context) {
        val intent = Intent(context, DataSyncService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else context.startService(intent)
    }
}