package com.org.childmonitorparent.child.services

import android.app.KeyguardManager
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.firestore.FirebaseFirestore
import com.org.childmonitorparent.R
import com.org.childmonitorparent.child.activities.ChildMainActivity
import com.org.childmonitorparent.child.broadcast_receivers.DeviceAdminReceivers
import com.org.childmonitorparent.child.broadcast_receivers.StartServicesReceiver
import com.org.childmonitorparent.child.workmanagers.LockWorker
import com.org.childmonitorparent.common.utils.NotificationUtils.createNotification
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.parent.models.DeviceLock
import java.util.concurrent.TimeUnit

class DeviceLockService : Service() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var context: Context
    private var isDeviceLock = false
    private val childId = PrefsHelper.getData("userId")
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var runnable: Runnable

    override fun onCreate() {
        super.onCreate()
        context = applicationContext
        val notification = createNotification(this, "Child Device Lock Active", "Monitoring for lock commands...")
        notification?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(1, it, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(1, it)
            }
        }
        startContinuousTask()
    }

    private fun startContinuousTask() {
        runnable = object : Runnable {
            override fun run() {
                println("🔥 Running task...")
                getDeviceLockStatus() // Your function to execute continuously
                handler.postDelayed(this, 5000) // Run every 5 seconds
            }
        }
        handler.post(runnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        getDeviceLockStatus()
        return START_STICKY
    }

    private fun getDeviceLockStatus() {
        db.collection("device_lock").whereEqualTo("childId", childId).get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val deviceLock = documents.documents[0].toObject(DeviceLock::class.java)
                    if (deviceLock != null) {
                        println("Device Lock Status: ${deviceLock.lock}")
                        if (deviceLock.lock) {
                            isDeviceLock = true
                            if (deviceLock.timestamp != null)
                                scheduleLock(this, deviceLock.timestamp)
                            else lockPhone()
                        } else {
                            isDeviceLock = false
                            unlockDevice()
                        }
                    }
                }
            }
            .addOnFailureListener {
                it.printStackTrace()
            }
    }

    private fun startDeviceLock() {
        val delay = 5000L
        if (isDeviceLock) {
            Handler(Looper.getMainLooper()).postDelayed({
                lockPhone()
                getDeviceLockStatus()
            }, delay)
        }
    }

    private fun lockPhone() {
        val devicePolicyManager =
            context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(context, DeviceAdminReceivers::class.java)

        if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.lockNow()
            println("✅ Phone Locked")
        } else {
            println("❌ Admin permission required")
        }
    }

    private fun unlockDevice() {
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (keyguardManager.isKeyguardLocked) {
                val activityIntent = Intent(this, ChildMainActivity::class.java)
                activityIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(activityIntent) // Open MainActivity to handle UI unlock
            }
        }
    }

    private fun scheduleLock(context: Context, lockTimestamp: Long) {
        val delayInSeconds = (lockTimestamp - System.currentTimeMillis())

        if (delayInSeconds > 0) {
            val lockWorkRequest = OneTimeWorkRequestBuilder<LockWorker>()
                .setInitialDelay(delayInSeconds, TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(context).enqueue(lockWorkRequest)

            println("⏳ Lock scheduled in $delayInSeconds seconds")
        } else {
            println("❌ Invalid time: Locking immediately!")
            //startDeviceLock()
            lockPhone()
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        val intent = Intent(this, StartServicesReceiver::class.java).apply {
            action = "DeviceLockServiceDestroyed"
        }
        sendBroadcast(intent)
    }
}