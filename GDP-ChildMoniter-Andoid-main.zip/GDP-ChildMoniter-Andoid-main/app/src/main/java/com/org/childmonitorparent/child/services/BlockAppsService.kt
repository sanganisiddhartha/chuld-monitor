package com.org.childmonitorparent.child.services

import android.app.*
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import com.org.childmonitorparent.child.broadcast_receivers.StartServicesReceiver
import com.org.childmonitorparent.common.utils.NotificationUtils.createNotification
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.parent.models.ChildInfo
import java.util.concurrent.TimeUnit

class BlockAppsService : Service() {
    private val db = Firebase.firestore
    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var componentName: ComponentName
    private var childId = PrefsHelper.getData("userId")
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var runnable: Runnable

    override fun onCreate() {
        super.onCreate()
        // 🔹 Call startForeground() immediately to avoid RemoteServiceException
        val notification = createNotification(this, "Child Apps Monitoring Service", "Tracking blocked apps in real-time")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        componentName = ComponentName(this, DeviceAdminReceiver::class.java)
        startContinuousTask()
    }

    private fun startContinuousTask() {
        runnable = object : Runnable {
            override fun run() {
                getChildInfo() // Your function to execute continuously
                handler.postDelayed(this, 5000) // Run every 5 seconds
            }
        }
        handler.post(runnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        //listenForBlockedApps()
        getChildInfo()
        return START_STICKY
    }

    private fun getChildInfo() {
        db.collection("children").whereEqualTo("childId", PrefsHelper.getData("userId")).get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    return@addOnSuccessListener
                }
                val child = documents.first().toObject(ChildInfo::class.java)
                childId = child.childId
                listenForBlockedApps()
            }
            .addOnFailureListener { e ->
                e.printStackTrace()
            }
    }

    private fun listenForBlockedApps() {
        db.collection("blocked_apps").document(childId)
            .addSnapshotListener { document, error ->
                if (error != null) {
                    println("Error listening for updates $error")
                    return@addSnapshotListener
                }
                if (document != null && document.exists()) {
                    blockedApps.clear()
                    blockedApps.addAll(document.get("blockedApps") as? List<String> ?: emptyList())
                    if (blockedApps.isNotEmpty()) {
                        startAppMonitoring()
                    }
                }
            }
    }

    private fun startAppMonitoring() {
        checkRunningApps()
    }

    private fun checkRunningApps() {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val startTime = endTime - TimeUnit.MINUTES.toMillis(1) // Check last 1 min

        val usageStats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            startTime,
            endTime
        )

        var recentApp: String? = null
        var recentTime: Long = 0

        for (usageStat in usageStats) {
            if (usageStat.lastTimeUsed > recentTime) {
                recentTime = usageStat.lastTimeUsed
                recentApp = usageStat.packageName
            }
        }

        if (recentApp != null && blockedApps.contains(recentApp)) {
            closeApp(recentApp)
        }
    }


    private fun closeApp(packageName: String) {
        // Optionally, kill the app process (requires root or system app permissions)
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.killBackgroundProcesses(packageName)

        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        val intent = Intent(this, StartServicesReceiver::class.java).apply {
            action = "BlockAppsServiceDestroyed"
        }
        sendBroadcast(intent)
    }

    companion object {
        val blockedApps = mutableListOf<String>()
        private const val NOTIFICATION_ID = 1
    }
}
