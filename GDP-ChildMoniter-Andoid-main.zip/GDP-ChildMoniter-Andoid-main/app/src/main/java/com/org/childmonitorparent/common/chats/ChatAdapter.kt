package com.org.childmonitorparent.common.chats

import android.content.Context
import android.graphics.Color
import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.databinding.ChatItemBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatAdapter(
    private val context: Context,
    private val messages: List<ChatMessage>,
    private val currentUserId: String, private val onClickTypeValue: OnClickTypeValue
) :
    RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    inner class ChatViewHolder(val binding: ChatItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(message: ChatMessage) {
            if (message.senderId == currentUserId) {
                // Show sender's message
                binding.myMessageLayout.visibility = View.VISIBLE
                binding.otherMessageLayout.visibility = View.GONE
                binding.myMessageTime.text = formatTime(message.timestamp)
                when (message.fileType) {
                    "image" -> {
                        binding.myImage.load(message.mediaUrl)
                        binding.myImage.visibility = View.VISIBLE
                        binding.myVideoLayout.visibility = View.GONE
                        binding.myMessage.visibility = View.GONE
                    }

                    "video" -> {
                        binding.myVideoView.load(message.mediaUrl)
                        binding.myVideoLayout.visibility = View.VISIBLE
                        binding.myImage.visibility = View.GONE
                        binding.myMessage.visibility = View.GONE
                    }

                    else -> {
                        binding.myMessage.text = message.message
                        binding.myMessage.visibility = View.VISIBLE
                        binding.myImage.visibility = View.GONE
                        binding.myVideoLayout.visibility = View.GONE
                    }
                }

                when (message.status) {
                    MessageStatus.SENDING -> {
                        binding.myMessageStatus.setImageResource(R.drawable.ic_check)
                        binding.myMessageStatus.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
                        binding.myMessageStatus.visibility = View.VISIBLE
                    }

                    MessageStatus.SENT -> {
                        binding.myMessageStatus.setImageResource(R.drawable.ic_done_all)
                        binding.myMessageStatus.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
                        binding.myMessageStatus.visibility = View.VISIBLE
                    }

                    MessageStatus.DELIVERED -> {
                        binding.myMessageStatus.setImageResource(R.drawable.ic_done_all)
                        binding.myMessageStatus.visibility = View.VISIBLE
                    }

                    MessageStatus.READ -> {
                        binding.myMessageStatus.setImageResource(R.drawable.ic_done_all)
                        binding.myMessageStatus.setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_IN)
                        binding.myMessageStatus.visibility = View.VISIBLE
                    }

                    MessageStatus.FAILED -> {
                        //binding.myMessageStatus.setImageResource(R.drawable.ic_error)
                        binding.myMessageStatus.visibility = View.VISIBLE
                    }
                }

                // Play Video on Click
                binding.myPlayImage.setOnClickListener {
                    onClickTypeValue.onClick(adapterPosition, "video", message.mediaUrl!!)
                }

            } else {
                // Show receiver's message
                binding.otherMessageLayout.visibility = View.VISIBLE
                binding.myMessageLayout.visibility = View.GONE
                binding.otherMessageTime.text = formatTime(message.timestamp)
                when (message.fileType) {
                    "image" -> {
                        binding.otherImage.load(message.mediaUrl)
                        binding.otherImage.visibility = View.VISIBLE
                        binding.otherVideoLayout.visibility = View.GONE
                        binding.otherMessage.visibility = View.GONE
                    }

                    "video" -> {
                        binding.otherVideoView.load(message.mediaUrl)
                        binding.otherVideoLayout.visibility = View.VISIBLE
                        binding.otherImage.visibility = View.GONE
                        binding.otherMessage.visibility = View.GONE
                    }

                    else -> {
                        binding.otherMessage.text = message.message
                        binding.otherMessage.visibility = View.VISIBLE
                        binding.otherImage.visibility = View.GONE
                        binding.otherVideoLayout.visibility = View.GONE
                    }
                }

                // Play Video on Click
                binding.otherPlayImage.setOnClickListener {
                    onClickTypeValue.onClick(adapterPosition, "video", message.mediaUrl!!)
                }
            }
        }

        private fun formatTime(timestamp: Long): String {
            val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val binding = ChatItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ChatViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        holder.bind(messages[position])
    }

    override fun getItemCount() = messages.size
}

