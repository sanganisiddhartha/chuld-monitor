package com.org.childmonitorparent.auth.models

import java.io.Serializable

data class User (
    val userType: String = "",
    val username: String = "",
    val email: String = "",
    var phone: String = "",
    var password: String = "",
    var parentId: String = "",
    var userId: String = "",
    var passwordSalt: String = ""
): Serializable{
    constructor() : this("", "", "", "", "", "", "", "")
}


