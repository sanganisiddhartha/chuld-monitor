package com.org.childmonitorparent.common.utils

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import java.io.File
import java.io.InputStream

object FileUtils {

    private fun getUrlFromUri(context: Context, uri: Uri): String? {
        var url: String? = null
        if ("content".equals(uri.scheme, ignoreCase = true)) {
            val projection = arrayOf(MediaStore.MediaColumns.DATA)
            val cursor = context.contentResolver.query(uri, projection, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val columnIndex = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                    url = it.getString(columnIndex)
                }
            }
        } else if ("file".equals(uri.scheme, ignoreCase = true)) {
            url = uri.path
        }
        return url
    }

    fun getFilePath(context: Context, uri: Uri): String? {
        return try {
            // Create the "SMS_Call" directory in local storage
            val smsCallDir = File(context.filesDir, "Child_Monitor")
            if (!smsCallDir.exists()) {
                smsCallDir.mkdir()
            }
            val inputStream = context.contentResolver.openInputStream(uri)
            val cacheFile = File(smsCallDir, getFileName(context, uri))
            inputStream?.use { input ->
                cacheFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            cacheFile.absolutePath
        } catch (e: Exception) {
            Log.e("FilePicker", "Failed to copy file", e)
            null
        }
    }

    private fun getFileName(context: Context, uri: Uri): String {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        var fileName: String = ""
        cursor?.use {
            if (it.moveToFirst()) {
                val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1) {
                    fileName = it.getString(nameIndex)
                }
            }
        }
        return fileName
    }

    private fun getFileSize(context: Context, fileUri: Uri): Long {
        // Get an InputStream from the file URI
        val inputStream: InputStream? = context.contentResolver.openInputStream(fileUri)
        // Check if the InputStream is valid
        if (inputStream != null) {
            val fileSize = inputStream.available().toLong()  // Returns size in bytes
            inputStream.close()
            return fileSize
        }

        // If InputStream is null, return 0
        return 0
    }
}