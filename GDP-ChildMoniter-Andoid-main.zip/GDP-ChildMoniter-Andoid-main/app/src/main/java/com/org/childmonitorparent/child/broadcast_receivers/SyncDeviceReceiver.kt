package com.org.childmonitorparent.child.broadcast_receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsMessage
import android.telephony.TelephonyManager
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.org.childmonitorparent.common.models.AppsInfo
import com.org.childmonitorparent.common.models.LogItem
import com.org.childmonitorparent.common.models.LogType
import com.org.childmonitorparent.common.utils.ActivityLogsHelper
import com.org.childmonitorparent.common.utils.ContactHelper.getContactName
import com.org.childmonitorparent.common.utils.PermissionsHelper
import com.org.childmonitorparent.common.utils.PrefsHelper
import java.util.Date

class SyncDeviceReceiver : BroadcastReceiver() {

    private val db = FirebaseFirestore.getInstance()
    private var lastPressTime: Long = 0
    private var pressCount = 0
    private lateinit var childId: String
    private lateinit var userType: String
    private lateinit var parentId: String

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return

        println("app action received ${intent.action}")

        childId = PrefsHelper.getData("userId") ?: return
        userType = PrefsHelper.getData("userType") ?: return
        parentId = PrefsHelper.getData("parentId") ?: return
        if (childId.isEmpty() || userType != "Child") return

        when (intent.action) {
            Intent.ACTION_PACKAGE_ADDED, Intent.ACTION_PACKAGE_REMOVED -> checkAppsAction(
                context,
                intent
            )

            TelephonyManager.ACTION_PHONE_STATE_CHANGED -> {
                if (PermissionsHelper.hasCallPermission(context))
                    checkCallAction(context, intent)
            }

            Telephony.Sms.Intents.SMS_RECEIVED_ACTION -> {
                if (PermissionsHelper.hasReadSMSPermission(context))
                    checkSmsAction(context, intent)
            }

            Intent.ACTION_SCREEN_OFF, Intent.ACTION_SCREEN_ON -> {
                val currentTime = System.currentTimeMillis()

                if (currentTime - lastPressTime < 1000) {  // Presses within 1 second
                    pressCount++
                } else {
                    pressCount = 1
                }
                lastPressTime = currentTime

                Log.d("SOS", "Power button pressed: $pressCount times")

                // Trigger SOS notification if pressed twice
                if (pressCount >= 2) {
                    triggerSOS(context)
                    pressCount = 0
                }
            }
        }
    }

    private fun triggerSOS(context: Context) {
        val sosData = hashMapOf(
            "userName" to PrefsHelper.getData("userName"),
            "receiverId" to parentId,
            "timestamp" to Date(),
            "message" to "⚠️ SOS Alert! Please contact to your child ${PrefsHelper.getData("userName")}.",
            "isShowAlert" to "true"
        )

        // Firestore - Send SOS Data
        db.collection("sos_alerts").document(parentId).set(sosData)
            .addOnSuccessListener {

            }
            .addOnFailureListener {
                it.printStackTrace()
            }
    }

    private fun checkAppsAction(context: Context, intent: Intent) {
        val packageName = intent.data?.schemeSpecificPart ?: return
        val packageManager = context.packageManager

        when (intent.action) {
            Intent.ACTION_PACKAGE_ADDED -> updateAppList(context, packageManager, packageName, true)
            Intent.ACTION_PACKAGE_REMOVED -> updateAppList(
                context,
                packageManager,
                packageName,
                false
            )
        }
    }

    private fun checkCallAction(context: Context, intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER) ?: return
        val name = getContactName(context, phoneNumber) ?: "Unknown"

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> logCall(name, phoneNumber, "Incoming")
            TelephonyManager.EXTRA_STATE_OFFHOOK -> logCall(name, phoneNumber, "Outgoing")
        }
    }

    private fun checkSmsAction(context: Context, intent: Intent) {
        val bundle: Bundle? = intent.extras
        val pdus: List<ByteArray>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            bundle?.getParcelableArrayList("pdus", ByteArray::class.java)
        } else {
            (bundle?.get("pdus") as? Array<*>?)?.filterIsInstance<ByteArray>()
        }

        pdus?.forEach { pdu ->
            val format = bundle?.getString("format")
            val message = SmsMessage.createFromPdu(pdu, format)
            logMessage(message.originatingAddress ?: "Unknown", message.messageBody)
        }
    }

    private fun logMessage(sender: String, message: String) {
        val childId = PrefsHelper.getData("userId") ?: return

        val messageDetails = mapOf(
            "name" to sender,
            "phoneNumber" to "Message",
            "type" to message,
            "timestamp" to ActivityLogsHelper.formatTimestamp(System.currentTimeMillis()),
            "logType" to LogType.MESSAGE.toString()
        )

        db.collection("message_logs").document(childId)
            .update("messageLogs", FieldValue.arrayUnion(messageDetails))
            .addOnSuccessListener { Log.d("SyncDeviceReceiver", "SMS logged successfully") }
            .addOnFailureListener { e -> Log.e("SyncDeviceReceiver", "SMS Error: ${e.message}") }
    }

    private fun logCall(name: String, phoneNumber: String, type: String) {
        val childId = PrefsHelper.getData("userId") ?: return

        val callDetails = mapOf(
            "name" to name,
            "phoneNumber" to phoneNumber,
            "type" to type,
            "duration" to "0",
            "timestamp" to ActivityLogsHelper.formatTimestamp(System.currentTimeMillis()),
            "logType" to LogType.CALL.toString()
        )

        db.collection("call_logs").document(childId)
            .update("callLogs", FieldValue.arrayUnion(callDetails))
            .addOnSuccessListener { Log.d("SyncDeviceReceiver", "Call log added successfully") }
            .addOnFailureListener { e -> Log.e("SyncDeviceReceiver", "Call Error: ${e.message}") }
    }

    private fun updateAppList(
        context: Context,
        packageManager: PackageManager,
        packageName: String,
        isInstalled: Boolean
    ) {
        val childId = PrefsHelper.getData("userId") ?: return
        val installedAppsRef = db.collection("child_apps").document(childId)

        if (isInstalled) {
            try {
                val appInfo =
                    packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
                val newApp = mapOf(
                    "appIcon" to "iconBase64",
                    "appName" to packageManager.getApplicationLabel(appInfo).toString(),
                    "packageName" to packageName
                )

                installedAppsRef.update("apps_list", FieldValue.arrayUnion(newApp))
                    .addOnSuccessListener {
                        Log.d(
                            "SyncDeviceReceiver",
                            "New app added: $packageName"
                        )
                    }
                    .addOnFailureListener { e ->
                        Log.e(
                            "SyncDeviceReceiver",
                            "Failed to add app: ${e.message}"
                        )
                    }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            installedAppsRef.get().addOnSuccessListener { document ->
                if (document.exists()) {
                    val appsList =
                        document.get("apps_list") as? List<HashMap<String, Any>> ?: emptyList()
                    val updatedList = appsList.filter { it["packageName"] != packageName }

                    installedAppsRef.set(mapOf("apps_list" to updatedList))
                        .addOnSuccessListener {
                            Log.d(
                                "SyncDeviceReceiver",
                                "App removed: $packageName"
                            )
                        }
                        .addOnFailureListener { e ->
                            Log.e(
                                "SyncDeviceReceiver",
                                "Failed to remove app: ${e.message}"
                            )
                        }
                }
            }
        }
    }
}
