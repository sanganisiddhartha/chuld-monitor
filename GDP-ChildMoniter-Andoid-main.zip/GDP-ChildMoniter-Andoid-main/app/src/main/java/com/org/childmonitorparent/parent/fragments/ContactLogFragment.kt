package com.org.childmonitorparent.parent.fragments

import LogAdapter
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.common.models.LogItem
import com.org.childmonitorparent.databinding.FragmentContactLogBinding
import com.org.childmonitorparent.common.viewmodels.LogsViewModel
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.parent.models.ChildInfo

class ContactLogFragment : Fragment(), OnClickTypeValue {
    private var _binding: FragmentContactLogBinding? = null
    private val binding get() = _binding!!
    private val logsViewModel: LogsViewModel by activityViewModels()
    private val sharedViewModel: SharedViewModel<ChildInfo> by activityViewModels()
    private lateinit var adapter: LogAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentContactLogBinding.inflate(inflater, container, false)

        adapter = LogAdapter(emptyList<LogItem>(), this@ContactLogFragment)
        binding.contactLogRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.contactLogRecyclerView.adapter = adapter


        logsViewModel.contactLogs.observe(viewLifecycleOwner) { logs ->
            adapter.updateData(logs)
        }

        getChildInfo()
        return binding.root
    }

    private fun getChildInfo() {
        sharedViewModel.childInfo.observe(viewLifecycleOwner) { childInfo ->
            logsViewModel.fetchContactLogs(requireContext(), childInfo.childId)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(position: Int, type: String, value: String) {
        when (type) {
            "call" -> openDialer(value)
            "message" -> openMessageBox(value)
        }
    }

    private fun openDialer(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$phoneNumber")
        }
        startActivity(intent)
    }

    private fun openMessageBox(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("smsto:$phoneNumber") // Opens default messaging app
        }
        startActivity(intent)
    }
}
