package com.org.childmonitorparent.parent.models

import java.io.Serializable

data class ChildInfo(
    var childId: String = "",
    var name: String = "",
    var homeAddress: String = "",
    var selectedAge: String = "",
    var selectedGender: String = "",
    var selectedHeight: String = "",
    var selectedWeight: String = "",
    var schoolName: String = "",
    var schoolAddress: String = "",
    var parentId: String = "",
    var isDeviceLocked: Boolean = false,
    var homeLocation: String = "",
    var schoolLocation: String = ""
) : Serializable {
    constructor() : this("","", "", "", "", "", "", "", "", "", false, "", "")
}
