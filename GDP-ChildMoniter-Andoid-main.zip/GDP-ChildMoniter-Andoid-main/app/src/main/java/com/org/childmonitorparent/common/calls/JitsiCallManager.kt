package com.org.childmonitorparent.common.calls

import android.content.Context
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions
import org.jitsi.meet.sdk.JitsiMeetView
import java.net.URL

object JitsiCallManager {

    private var jitsiView: JitsiMeetView? = null

    fun startCall(context: Context, roomId: String) {
        jitsiView = JitsiMeetView(context)

        val options = JitsiMeetConferenceOptions.Builder()
            .setServerURL(URL("https://meet.jit.si")) // Public Jitsi server
            .setRoom(roomId) // Unique Room ID
            .setAudioOnly(true) // 🔥 Voice-only call
            .setFeatureFlag("invite.enabled", false) // Disable invite
            .setFeatureFlag("welcomepage.enabled", true) // Disable welcome page
            .build()

        jitsiView?.join(options)
    }

    fun endCall() {
        jitsiView?.left
        jitsiView = null
    }
}
