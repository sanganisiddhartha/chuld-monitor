import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.databinding.ActivityLogItemCallBinding
import com.org.childmonitorparent.databinding.ActivityLogItemMessageBinding
import com.org.childmonitorparent.databinding.ActivityLogItemContactBinding
import com.org.childmonitorparent.common.models.LogItem

class LogAdapter(private var logs: List<LogItem>, private var onClickTypeValue: OnClickTypeValue) :
    RecyclerView.Adapter<LogAdapter.BaseViewHolder<out ViewBinding>>() { // 🔹 FIXED

    companion object {
        private const val TYPE_CALL = 0
        private const val TYPE_MESSAGE = 1
        private const val TYPE_CONTACT = 2
    }

    override fun getItemViewType(position: Int): Int {
        return logs[position].logType.type
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<out ViewBinding> {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_CALL -> CallViewHolder(ActivityLogItemCallBinding.inflate(inflater, parent, false))
            TYPE_MESSAGE -> MessageViewHolder(
                ActivityLogItemMessageBinding.inflate(
                    inflater,
                    parent,
                    false
                )
            )

            TYPE_CONTACT -> ContactViewHolder(
                ActivityLogItemContactBinding.inflate(
                    inflater,
                    parent,
                    false
                )
            )

            else -> throw IllegalArgumentException("Invalid ViewType")
        }
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<out ViewBinding>,
        position: Int
    ) { // 🔹 FIXED
        val logItem = logs[position]
        when (holder) {
            is CallViewHolder -> holder.bind(logItem)
            is MessageViewHolder -> holder.bind(logItem)
            is ContactViewHolder -> holder.bind(logItem)
        }
    }

    override fun getItemCount() = logs.size

    // ✅ FIX: Ensuring BaseViewHolder Enforces `ViewBinding`
    abstract class BaseViewHolder<T : ViewBinding>(protected val binding: T) :
        RecyclerView.ViewHolder(binding.root) {
        abstract fun bind(log: LogItem)
    }

    class CallViewHolder(binding: ActivityLogItemCallBinding) :
        BaseViewHolder<ActivityLogItemCallBinding>(binding) {
        override fun bind(log: LogItem) {
            binding.name.text = log.name
            binding.number.text = log.number
            binding.textTimestamp.text = log.timestamp
            binding.callDuration.text = log.extraInfo
            binding.textInitial.text = log.name?.take(1)?.uppercase() ?: "?"

            binding.callType.visibility = View.VISIBLE
            when (log.subtitle) {
                "Missed Call" -> binding.callType.setImageResource(R.drawable.ic_call_missed)
                "Outgoing Call" -> binding.callType.setImageResource(R.drawable.ic_call_made)
                "Incoming Call" -> binding.callType.setImageResource(R.drawable.ic_call_received)
            }
        }
    }

    class MessageViewHolder(binding: ActivityLogItemMessageBinding) :
        BaseViewHolder<ActivityLogItemMessageBinding>(binding) {
        override fun bind(log: LogItem) {
            binding.nameOrNumber.text = log.number
            binding.textTimestamp.text = log.timestamp
            binding.message.text = log.extraInfo
            binding.textInitial.text = log.number?.take(1)?.uppercase() ?: "?"
        }
    }

    inner class ContactViewHolder(binding: ActivityLogItemContactBinding) :
        BaseViewHolder<ActivityLogItemContactBinding>(binding) {
        override fun bind(log: LogItem) {
            binding.nameOrNumber.text = log.name
            binding.textInitial.text = log.name?.take(1)?.uppercase() ?: "?"

            binding.callImage.setOnClickListener {
                onClickTypeValue.onClick(adapterPosition, "call", log.number ?: "")
            }

            binding.messageImage.setOnClickListener {
                onClickTypeValue.onClick(adapterPosition, "message", log.number ?: "")
            }
        }
    }

    fun updateData(newLogs: List<LogItem>) {
        logs = newLogs
        notifyDataSetChanged()
    }
}

