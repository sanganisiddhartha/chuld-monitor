package com.org.childmonitorparent.parent.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.databinding.ActivityChildDetailsBinding
import com.org.childmonitorparent.databinding.CustomToolbarBinding
import com.org.childmonitorparent.parent.models.ChildInfo

class ChildDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChildDetailsBinding
    private lateinit var customToolbarBinding: CustomToolbarBinding
    // ✅ Correct way to initialize SharedViewModel
    private val sharedViewModel: SharedViewModel<ChildInfo> by viewModels()
    private lateinit var roomId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChildDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ✅ Toolbar Setup
        customToolbarBinding = binding.toolBar
        customToolbarBinding.rightAction.setImageResource(R.drawable.ic_browse_activity)
        customToolbarBinding.rightAction.visibility = View.VISIBLE

        customToolbarBinding.leftAction.setOnClickListener { finish() }
        customToolbarBinding.rightAction.setOnClickListener {
            startActivity(Intent(this, SearchLogsActivity::class.java).apply {
                putExtra("childInfo", sharedViewModel.childInfo.value)
            })
        }

        // ✅ Get ChildInfo from Intent safely
        val childInfo = intent.getSerializableExtra("childInfo") as? ChildInfo
        if (childInfo != null) {
            roomId = "${childInfo.parentId}_${childInfo.childId}"
            sharedViewModel.setChildInfo(childInfo)
            customToolbarBinding.title.text = childInfo.name
        } else {
            // Handle case when childInfo is null
            finish() // Close activity if data is missing
            return
        }

        // ✅ Fix: Use correct NavController ID
        val navView: BottomNavigationView = binding.navView
        val navController =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment)?.findNavController()
        navController?.let {
            navView.setupWithNavController(it)
        }
    }
}
