package com.org.childmonitorparent.common.models

data class AppsListWrapper(
    val apps_list: List<AppsInfo> = emptyList()
)
