package com.org.childmonitorparent.common.utils

import androidx.recyclerview.widget.DiffUtil
import com.org.childmonitorparent.child.models.PermissionItem

class PermissionDiffCallback(
    private val oldList: List<PermissionItem>,
    private val newList: List<PermissionItem>
) : DiffUtil.Callback() {

    override fun getOldListSize() = oldList.size
    override fun getNewListSize() = newList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldList[oldItemPosition].permission == newList[newItemPosition].permission // Ensure `PermissionItem` has a unique `id`
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldList[oldItemPosition] == newList[newItemPosition] // Compare entire object
    }
}
