package com.org.childmonitorparent.common.calls

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore


class CallViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val _isCallActive = MutableLiveData<Boolean>()
    val isCallActive: MutableLiveData<Boolean> = _isCallActive


    fun saveCall(roomId: String, status: String, name: String, receiverId: String) {
        val callData = hashMapOf(
            "roomId" to roomId,
            "status" to status,
            "callerName" to name,
            "receiverId" to receiverId,
            "timestamp" to System.currentTimeMillis()
        )

        db.collection("calls").document(roomId)
            .set(callData)
            .addOnSuccessListener {
                println("Call saved!")
                listenForCalls(roomId)
            }
            .addOnFailureListener { println("Failed to save call!") }
    }

    fun listenForCalls(roomId: String) {
        db.collection("calls").document(roomId)
            .addSnapshotListener { snapshot, _ ->
                if (snapshot?.getString("status") == "ended") {
                    _isCallActive.value = false
                } else if (snapshot?.getString("status") == "active") {
                    _isCallActive.value = true
                }
            }
    }
}