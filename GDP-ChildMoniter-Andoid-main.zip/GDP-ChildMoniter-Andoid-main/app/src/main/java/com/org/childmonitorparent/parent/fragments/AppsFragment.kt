package com.org.childmonitorparent.parent.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.common.models.AppsInfo
import com.org.childmonitorparent.databinding.FragmentAppsBinding
import com.org.childmonitorparent.parent.adapters.AppListAdapter
import com.org.childmonitorparent.common.viewmodels.AppsViewModel
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.parent.models.ChildInfo

class AppsFragment : Fragment(), OnClickTypeValue {

    private var _binding: FragmentAppsBinding? = null
    private val binding get() = _binding!!

    private val sharedViewModel: SharedViewModel<ChildInfo> by activityViewModels()
    private lateinit var appsViewModel: AppsViewModel

    private var appsList = mutableListOf<AppsInfo?>()
    private var blockedApps = mutableListOf<String>()
    private lateinit var adapter: AppListAdapter
    private var childId: String? = null  // ✅ Now it's dynamic

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAppsBinding.inflate(inflater, container, false)

        // ✅ Initialize ViewModel here
        appsViewModel = AppsViewModel(requireContext())

        binding.appsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = AppListAdapter(blockedApps, appsList, this@AppsFragment)
        binding.appsRecyclerView.adapter = adapter

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ✅ Observe child apps
        appsViewModel.childApps.observe(viewLifecycleOwner) { apps ->
            appsList.clear()
            appsList.addAll(apps)
            adapter.notifyDataSetChanged()
        }
        // ✅ Observe child blocked apps
        appsViewModel.blockedApps.observe(viewLifecycleOwner) { blocked ->
            blockedApps.clear()
            blockedApps.addAll(blocked)
            adapter.notifyDataSetChanged()
        }

        // ✅ Observe sharedViewModel for child ID (only observe once)
        sharedViewModel.childInfo.observe(viewLifecycleOwner) { childInfo ->
            childInfo?.childId?.let {
                if (childId == null) {  // Prevent multiple calls
                    childId = it
                    appsViewModel.getChildApps(it) // ✅ Dynamic child ID
                    appsViewModel.listenForBlockedApps(it) // ✅ Real-time updates
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(position: Int, type: String, value: String) {
        appsList[position]?.let { app ->  // ✅ Avoid null pointer crash
            val isBlocked = value == "true"
            if (isBlocked) {
                blockedApps.add(app.packageName)
            } else {
                blockedApps.remove(app.packageName)
            }

            childId?.let {
                appsViewModel.saveBlockedApps(it, blockedApps)
            }
        }
    }
}
