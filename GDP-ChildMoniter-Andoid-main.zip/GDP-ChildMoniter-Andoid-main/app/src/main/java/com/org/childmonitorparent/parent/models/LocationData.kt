package com.org.childmonitorparent.parent.models

data class LocationData(
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long,
    val childName: String,
    val childId: String,
    val parentId: String,
    val isOutside: Boolean
)