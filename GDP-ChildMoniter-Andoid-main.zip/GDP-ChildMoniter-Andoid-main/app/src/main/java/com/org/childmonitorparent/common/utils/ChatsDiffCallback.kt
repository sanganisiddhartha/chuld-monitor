package com.org.childmonitorparent.common.utils

import androidx.recyclerview.widget.DiffUtil
import com.org.childmonitorparent.child.models.PermissionItem
import com.org.childmonitorparent.common.chats.ChatMessage

class ChatsDiffCallback(
    private val oldList: List<ChatMessage>,
    private val newList: List<ChatMessage>
) : DiffUtil.Callback() {

    override fun getOldListSize() = oldList.size
    override fun getNewListSize() = newList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldList[oldItemPosition].message == newList[newItemPosition].message // Ensure `PermissionItem` has a unique `id`
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldList[oldItemPosition] == newList[newItemPosition] // Compare entire object
    }
}
