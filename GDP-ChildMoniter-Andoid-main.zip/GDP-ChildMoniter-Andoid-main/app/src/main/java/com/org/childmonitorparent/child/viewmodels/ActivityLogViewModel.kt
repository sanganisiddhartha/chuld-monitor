package com.org.childmonitorparent.child.viewmodels

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.org.childmonitorparent.common.models.LogItem
import com.org.childmonitorparent.common.utils.ActivityLogsHelper

class ActivityLogViewModel(application: Application) : AndroidViewModel(application) {
    private val _callLogs = MutableLiveData<List<LogItem>>()
    val callLogs: LiveData<List<LogItem>> get() = _callLogs

    private val _messageLogs = MutableLiveData<List<LogItem>>()
    val messageLogs: LiveData<List<LogItem>> get() = _messageLogs

    private val _contactLogs = MutableLiveData<List<LogItem>>()
    val contactLogs: LiveData<List<LogItem>> get() = _contactLogs


    fun fetchCallLogs(context: Context) {
        _callLogs.postValue(ActivityLogsHelper.callLogs(context))
    }

    fun fetchMessageLogs(context: Context) {
        _messageLogs.postValue(ActivityLogsHelper.messageLogs(context))
    }

    fun fetchContactLogs(context: Context) {
        _contactLogs.postValue(ActivityLogsHelper.contactLogs(context))
    }
}