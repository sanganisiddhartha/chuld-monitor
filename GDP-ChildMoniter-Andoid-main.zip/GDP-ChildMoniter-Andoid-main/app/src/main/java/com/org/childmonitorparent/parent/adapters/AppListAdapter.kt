package com.org.childmonitorparent.parent.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.databinding.ItemAppsBinding
import com.org.childmonitorparent.common.models.AppsInfo
import com.org.childmonitorparent.common.utils.Base64Functions

class AppListAdapter(
    private val blockedApps: MutableList<String>,
    private val apps: List<AppsInfo?>,
    private val onClickTypeValue: OnClickTypeValue
) : RecyclerView.Adapter<AppListAdapter.AppViewHolder>() {

    inner class AppViewHolder(private val binding: ItemAppsBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(app: AppsInfo) {
            Base64Functions.setBase64ToImageView(app.appIcon, binding.appIcon)
            binding.appName.text = app.appName
            binding.packageName.text = app.packageName
            binding.textInitial.text = app.appName?.firstOrNull()?.uppercaseChar()?.toString() ?: "?"

            // ✅ Fix: Remove old listener before setting a new one
            binding.switchButton.setOnCheckedChangeListener(null)
            binding.switchButton.isChecked = blockedApps.contains(app.packageName)

            binding.switchButton.setOnCheckedChangeListener { _, isChecked ->
                // ✅ Fix: Use bindingAdapterPosition to ensure correct position
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    onClickTypeValue.onClick(adapterPosition, app.packageName, isChecked.toString())
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        apps[position]?.let { holder.bind(it) }  // ✅ Fix: Avoid NullPointerException
    }

    override fun getItemCount(): Int {
        return apps.filterNotNull().size
    }
}
