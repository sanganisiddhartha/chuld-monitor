package com.org.childmonitorparent.common.interfaces

interface OnClickPosition {
    fun onClick(position: Int)
}