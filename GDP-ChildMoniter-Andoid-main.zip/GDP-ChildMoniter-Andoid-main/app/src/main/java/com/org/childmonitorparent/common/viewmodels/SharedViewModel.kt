package com.org.childmonitorparent.common.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SharedViewModel<T> : ViewModel() {

    private val _childInfo = MutableLiveData<T>()
    val childInfo: LiveData<T> = _childInfo

    fun setChildInfo(info: T) {
        _childInfo.value = info
    }
}