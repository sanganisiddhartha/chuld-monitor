package com.org.childmonitorparent.common.viewmodels

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.org.childmonitorparent.common.models.LogItem
import com.org.childmonitorparent.common.models.LogType
import com.org.childmonitorparent.common.utils.ProgressDialogHelper

class LogsViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()
    private val _callLogs = MutableLiveData<List<LogItem>>()
    val callLogs: LiveData<List<LogItem>> get() = _callLogs
    private val _messageLogs = MutableLiveData<List<LogItem>>()
    val messageLogs: LiveData<List<LogItem>> get() = _messageLogs
    private val _contactLogs = MutableLiveData<List<LogItem>>()
    val contactLogs: LiveData<List<LogItem>> get() = _contactLogs

    fun saveCallLogs(childId: String, callLogs: List<LogItem>) {
        val callLogsRef = db.collection("call_logs").document(childId)
        val data = mapOf("callLogs" to callLogs)
        callLogsRef.set(data, SetOptions.merge())
            .addOnSuccessListener {
                println("Call logs saved successfully")
            }
            .addOnFailureListener { e ->
                println("Error saving call logs: ${e.message}")
            }
    }

    fun saveMessageLogs(childId: String, messageLogs: List<LogItem>) {
        val messageLogsRef = db.collection("message_logs").document(childId)
        val data = mapOf("messageLogs" to messageLogs)
        messageLogsRef.set(data, SetOptions.merge())
            .addOnSuccessListener {
                println("Message logs saved successfully")
            }
            .addOnFailureListener { e ->
                println("Error saving message logs: ${e.message}")
            }
    }

    fun saveContactLogs(childId: String, contactLogs: List<LogItem>) {
        val contactLogsRef = db.collection("contact_logs").document(childId)
        val data = mapOf("contactLogs" to contactLogs)
        contactLogsRef.set(data, SetOptions.merge())
            .addOnSuccessListener {
                println("Contact logs saved successfully")
            }
            .addOnFailureListener { e ->
                println("Error saving contact logs: ${e.message}")
            }
    }

    fun fetchCallLogs(context: Context, childId: String) {
        ProgressDialogHelper.showProgressDialog(context, "Fetching Call Logs")
        val callLogsRef = db.collection("call_logs").document(childId)

        callLogsRef.addSnapshotListener { document, error ->
            ProgressDialogHelper.hideProgressDialog()
            if (error != null) {
                Log.e("Firestore", "Error fetching call logs: ${error.message}")
                return@addSnapshotListener
            }

            if (document != null && document.exists()) {
                val callLogs =
                    document.get("callLogs") as? List<HashMap<String, Any>> ?: emptyList()
                val logsList = callLogs.mapNotNull { logData ->
                    try {
                        LogItem(
                            name = logData["name"] as? String ?: "Unknown",
                            number = logData["number"] as? String ?: "Unknown",
                            subtitle = logData["subtitle"] as? String ?: "Unknown",
                            extraInfo = logData["extraInfo"] as? String ?: "Unknown",
                            timestamp = logData["timestamp"] as? String
                                ?: "Unknown", // ✅ Fix timestamp
                            logType = LogType.valueOf(
                                logData["logType"] as? String ?: "CALL"
                            ) // ✅ Fix logType
                        )
                    } catch (e: Exception) {
                        Log.e("Firestore", "Error parsing call log", e)
                        null
                    }
                }

                Log.d("Firestore", "Fetched Call Logs: $logsList")
                _callLogs.value = logsList
            } else {
                Log.d("Firestore", "No call logs found for child ID: $childId")
                ProgressDialogHelper.hideProgressDialog()
                _callLogs.value = emptyList()
            }
        }
    }


    fun fetchMessageLogs(context: Context, childId: String) {
        ProgressDialogHelper.showProgressDialog(context, "Fetching SMS Logs")
        val messageLogsRef = db.collection("message_logs").document(childId)
        messageLogsRef.addSnapshotListener { document, error ->
            ProgressDialogHelper.hideProgressDialog()
            if (error != null) {
                println("Error fetching message logs: ${error.message}")
                return@addSnapshotListener
            }
            if (document != null && document.exists()) {
                val messageLogs =
                    document.get("messageLogs") as? List<HashMap<String, Any>> ?: emptyList()
                val logsList = messageLogs.mapNotNull { logData ->
                    try {
                        LogItem(
                            name = logData["name"] as? String ?: "Unknown",
                            number = logData["number"] as? String ?: "Unknown",
                            subtitle = logData["subtitle"] as? String ?: "Unknown",
                            extraInfo = logData["extraInfo"] as? String ?: "Unknown",
                            timestamp = logData["timestamp"] as? String
                                ?: "Unknown", // ✅ Fix timestamp
                            logType = LogType.valueOf(logData["logType"] as? String ?: "MESSAGE")
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        null
                    }
                }
                _messageLogs.value = logsList
            } else {
                ProgressDialogHelper.hideProgressDialog()
                _messageLogs.value = emptyList()
            }
        }
    }

    fun fetchContactLogs(context: Context, childId: String) {
        ProgressDialogHelper.showProgressDialog(context, "Fetching Contacts Logs")
        val contactLogsRef = db.collection("contact_logs").document(childId)
        contactLogsRef.addSnapshotListener { document, error ->
            ProgressDialogHelper.hideProgressDialog()
            if (error != null) {
                println("Error fetching contact logs: ${error.message}")
                return@addSnapshotListener
            }
            if (document != null && document.exists()) {
                val contactLogs =
                    document.get("contactLogs") as? List<HashMap<String, Any>> ?: emptyList()
                val logsList = contactLogs.mapNotNull { logData ->
                    try {
                        LogItem(
                            name = logData["name"] as? String ?: "Unknown",
                            number = logData["number"] as? String ?: "Unknown",
                            subtitle = logData["subtitle"] as? String ?: "Unknown",
                            extraInfo = logData["extraInfo"] as? String ?: "Unknown",
                            timestamp = logData["timestamp"] as? String
                                ?: "Unknown", // ✅ Fix timestamp
                            logType = LogType.valueOf(logData["logType"] as? String ?: "CONTACTS")
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        null
                    }
                }
                _contactLogs.value = logsList
            } else {
                ProgressDialogHelper.hideProgressDialog()
                _contactLogs.value = emptyList()
            }
        }
    }
}