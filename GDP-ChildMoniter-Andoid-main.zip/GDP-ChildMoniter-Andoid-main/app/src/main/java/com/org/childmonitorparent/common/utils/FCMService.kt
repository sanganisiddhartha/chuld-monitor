package com.org.childmonitorparent.common.utils

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.google.firebase.firestore.FirebaseFirestore

class FCMService : FirebaseMessagingService() {
    val db = FirebaseFirestore.getInstance()
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM", "New FCM Token: $token")
        /*if (PrefsHelper.getData("userType") == "Parent")
            saveTokenToFirestore(token)*/
    }

    private fun saveTokenToFirestore(token: String) {
        val parentId = PrefsHelper.getData("parentId")  // TODO: Replace with the actual parent ID
        if (parentId.isEmpty()) return
        db.collection("parent_devices").document(parentId)
            .set(mapOf("fcmToken" to token))
            .addOnSuccessListener {
                Log.d("Firestore", "FCM Token saved for parent")
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error saving FCM token", e)
            }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        remoteMessage.notification?.let {
            NotificationUtils.showPushNotification(applicationContext, it.title, it.body)
        }
    }
}
