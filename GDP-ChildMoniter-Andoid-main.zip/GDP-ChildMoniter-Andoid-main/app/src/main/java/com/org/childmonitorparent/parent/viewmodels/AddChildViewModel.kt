package com.org.childmonitorparent.parent.viewmodels

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.org.childmonitorparent.parent.models.AddChildInfo
import com.org.childmonitorparent.parent.models.ChildInfo
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.utils.ProgressDialogHelper
import com.org.childmonitorparent.parent.models.DeviceLock

class AddChildViewModel : ViewModel() {
    private val _addChildInfo = MutableLiveData<AddChildInfo>()
    private val addChildInfo: LiveData<AddChildInfo> = _addChildInfo
    private val _childInfo = MutableLiveData<ChildInfo>()
    val childInfo: LiveData<ChildInfo> = _childInfo
    private val _isLockActionChanged = MutableLiveData<Boolean>()
    val isLockActionChanged: LiveData<Boolean> = _isLockActionChanged
    private val _childList = MutableLiveData<List<ChildInfo>>()
    val childList: LiveData<List<ChildInfo>> = _childList
    private val db = FirebaseFirestore.getInstance()

    fun setAddChildInfo(info: AddChildInfo) {
        _addChildInfo.value = info
    }

    fun getAddChildInfo(): AddChildInfo? {
        return addChildInfo.value
    }

    fun saveChildInfo(context: Context, addChildInfo: AddChildInfo, onComplete: (Boolean) -> Unit) {
        ProgressDialogHelper.showProgressDialog(context, "Saving Child...")
        db.collection("children")
            .add(addChildInfo)
            .addOnSuccessListener { documentReference ->
                // Handle success
                onComplete(true)
                ProgressDialogHelper.hideProgressDialog()
                Log.d("AddChildViewModel", "Child added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                // Handle failure
                ProgressDialogHelper.hideProgressDialog()
                onComplete(false)
                Log.w("AddChildViewModel", "Error adding child", e)
            }
    }

    fun updateChildInfo(context: Context, childInfo: ChildInfo, onComplete: (Boolean) -> Unit) {
        ProgressDialogHelper.showProgressDialog(context, "Updating Child Info...")
        println("childId===$childInfo")
        // 🔹 Fetch the child's document from Firestore
        db.collection("children").whereEqualTo("childId", childInfo.childId)
            .limit(1)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    println("doc===empty doc")
                    ProgressDialogHelper.hideProgressDialog()
                    onComplete(false)
                    return@addOnSuccessListener
                }

                val documentId = documents.documents.first().id  // Get Firestore document ID
                println("docId===$documentId")
                // 🔹 Convert addChildInfo to a Firestore-friendly map
                val childInfoMap = mapOf(
                    "homeAddress" to childInfo.homeAddress,
                    "schoolAddress" to childInfo.schoolAddress,
                    "homeLocation" to childInfo.homeLocation,
                    "schoolLocation" to childInfo.schoolLocation,
                    "selectedAge" to childInfo.selectedAge,
                    "selectedGender" to childInfo.selectedGender,
                    "selectedHeight" to childInfo.selectedHeight,
                    "selectedWeight" to childInfo.selectedWeight,
                    "schoolName" to childInfo.schoolName
                )

                println("Updating with data: $childInfoMap")

                // 🔹 Update Firestore document
                db.collection("children").document(documentId).set(childInfoMap, SetOptions.merge())
                    .addOnSuccessListener {
                        println("child===updated")
                        ProgressDialogHelper.hideProgressDialog()
                        onComplete(true)
                    }
                    .addOnFailureListener { e ->
                        println("child===error")
                        ProgressDialogHelper.hideProgressDialog()
                        Log.e("FirestoreUpdate", "Error updating child info", e)
                        onComplete(false)
                    }
            }
            .addOnFailureListener { e ->
                println("child===fetching error")
                ProgressDialogHelper.hideProgressDialog()
                Log.e("FirestoreFetch", "Error fetching child info", e)
                onComplete(false)
            }
    }


    fun getAllChild(context: Context, showDialog: Boolean): LiveData<List<ChildInfo>> {
        if (showDialog) ProgressDialogHelper.showProgressDialog(context, "Fetching Kids...")

        val userId = PrefsHelper.getData("userId")

        db.collection("children")
            .whereEqualTo("parentId", userId)
            .addSnapshotListener { documents, error ->
                if (error != null) {
                    error.printStackTrace()
                    _childList.value = emptyList()
                    ProgressDialogHelper.hideProgressDialog()
                    return@addSnapshotListener
                }

                if (documents == null || documents.isEmpty) {
                    _childList.value = emptyList()
                    ProgressDialogHelper.hideProgressDialog()
                    return@addSnapshotListener
                }

                val tempChildList = mutableListOf<ChildInfo>()
                val totalChildren = documents.size()
                var completedRequests = 0

                documents.forEach { doc ->
                    val child = doc.toObject(ChildInfo::class.java)

                    // Fetch device lock status asynchronously
                    getDeviceLockStatus(child.childId) { isLocked ->
                        child.isDeviceLocked = isLocked
                        tempChildList.add(child)
                        completedRequests++

                        // If all async calls are completed, update LiveData
                        if (completedRequests == totalChildren) {
                            _childList.postValue(tempChildList)
                            ProgressDialogHelper.hideProgressDialog()
                        }
                    }
                }
            }

        return _childList
    }

    fun getChildInfo() {
        db.collection("children").whereEqualTo("childId", PrefsHelper.getData("userId")).get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    return@addOnSuccessListener
                }
                val child = documents.first().toObject(ChildInfo::class.java)
                _childInfo.value = child
            }
            .addOnFailureListener { e ->
                e.printStackTrace()
            }
    }


    private fun getDeviceLockStatus(childId: String, onResult: (Boolean) -> Unit) {
        db.collection("device_lock").whereEqualTo("childId", childId).get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val deviceLock = documents.documents[0].toObject(DeviceLock::class.java)
                    onResult(deviceLock?.lock ?: false) // Return the fetched lock status
                } else {
                    onResult(false) // Default to false if no document is found
                }
            }
            .addOnFailureListener {
                it.printStackTrace()
                onResult(false) // Handle failure and return false
            }
    }

    fun sendLockRequest(childId: String, lock: Boolean, lockTime: Long?) {
        val deviceLock = DeviceLock(childId, lock, lockTime)
        db.collection("device_lock").document(childId).set(deviceLock)
            .addOnSuccessListener {
                println("✅ Lock command sent")
                _isLockActionChanged.value = true
            }
            .addOnFailureListener { e ->
                println("❌ Failed: ${e.message}")
                _isLockActionChanged.value = false
            }
    }

    fun getParentName(parentId: String) {
        db.collection("user").whereEqualTo("userId", parentId).get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    return@addOnSuccessListener
                }
                val parentName = documents.documents[0].getString("username") ?: "Unknown"
                PrefsHelper.saveData("parentName", parentName)
            }
            .addOnFailureListener { e ->
                e.printStackTrace()
            }
    }
}