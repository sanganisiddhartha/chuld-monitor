package com.org.childmonitorparent.child.broadcast_receivers

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore
import com.org.childmonitorparent.child.services.DeviceLockService
import com.org.childmonitorparent.common.utils.PrefsHelper

class DeviceAdminReceivers : DeviceAdminReceiver() {

    private val db = FirebaseFirestore.getInstance()
    private val childId = PrefsHelper.getData("userId")

    override fun onEnabled(context: Context, intent: Intent) {
        Toast.makeText(context, "Device Admin Enabled", Toast.LENGTH_SHORT).show()
        updateChildPermissionStatus(true)
        callDeviceLockService(context)
    }

    private fun callDeviceLockService(context: Context) {
        val serviceIntent = Intent(context, DeviceLockService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent) // Required for Android 8+
        } else {
            context.startService(serviceIntent)
        }
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Toast.makeText(context, "Device Admin Disabled", Toast.LENGTH_SHORT).show()
        updateChildPermissionStatus(false)
    }

    /**
     * 🔹 Update child's device admin permission status in Firestore
     */
    private fun updateChildPermissionStatus(granted: Boolean) {
        val permissionsRef = db.collection("child_permissions").document(childId)
        permissionsRef.get().addOnSuccessListener { document ->
            if (document.exists()) {
                // Update existing permission
                val permissionsList =
                    document.get("permissions_list") as? MutableList<Map<String, Any>>
                        ?: mutableListOf()

                val updatedPermissions = permissionsList.map {
                    if (it["permission"] == "Device Lock") {
                        it.toMutableMap().apply { this["granted"] = granted }
                    } else it
                }.toMutableList()

                permissionsRef.update("permissions_list", updatedPermissions)
                    .addOnSuccessListener { println("Permission updated successfully") }
                    .addOnFailureListener { println("Failed to update permission $it") }

            }
        }
    }
}
