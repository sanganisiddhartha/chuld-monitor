package com.org.childmonitorparent.child.viewmodels

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.org.childmonitorparent.child.models.SearchLogs
import com.org.childmonitorparent.common.utils.PrefsHelper

class SearchLogsViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()
    private val _searchLogs = MutableLiveData<List<String>>()
    val searchLogs: MutableLiveData<List<String>> = _searchLogs
    private val _blockedKeywords = MutableLiveData<List<String>>()
    val blockedKeywords: MutableLiveData<List<String>> = _blockedKeywords


    fun saveBlockedKeyword(childId: String, blockedKeyword: List<String>) {
        val blockedKeywordsRef = db.collection("blocked_keyword").document(childId)
        val data = mapOf("blockedKeyword" to blockedKeyword) // 🔥 Store as a map
        blockedKeywordsRef.set(data, SetOptions.merge()) // 🔥 Merge instead of overwriting
            .addOnSuccessListener {
                Log.d("Firestore", "Blocked keyword saved successfully")
                listenForBlockedKeywords(childId) // 🔥 Start listening for updates
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error saving blocked keyword", e)
            }
    }

    fun listenForBlockedKeywords(childId: String) {
        val blockedKeywordsRef = db.collection("blocked_keyword").document(childId)

        blockedKeywordsRef.addSnapshotListener { documentSnapshot, error ->
            if (error != null) {
                Log.e("Firestore", "Error listening for updates", error)
                return@addSnapshotListener
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                val blockedKeywordList =
                    documentSnapshot.get("blockedKeyword") as? List<String> ?: emptyList()
                _blockedKeywords.value = blockedKeywordList // 🔥 Live update in ViewModel
            } else {
                Log.d("Firestore", "No blocked keyword found")
                _blockedKeywords.value = emptyList()
            }
        }
    }

    fun isSearchAllowed(query: String, onResult: (Boolean) -> Unit) {
        db.collection("blocked_keywords").get()
            .addOnSuccessListener { documents ->
                val blockedWords = documents.map { it.getString("keyword") ?: "" }
                val isBlocked = blockedWords.any { query.contains(it, ignoreCase = true) }
                onResult(!isBlocked)
            }
    }

    fun logSearchQuery(childId: String, query: String) {
        val searchLogsRef = db.collection("search_logs").document(childId)
        searchLogsRef.get().addOnSuccessListener { document ->
            val existingQueries = document.get("queryLogs") as? List<String> ?: emptyList()
            // Append new query while keeping history
            val updatedQueries = existingQueries.toMutableList().apply {
                add(query)
            }
            // Save updated list
            val searchLog = mapOf("queryLogs" to updatedQueries)
            searchLogsRef.set(searchLog, SetOptions.merge())
                .addOnSuccessListener {
                    Log.d("Firestore", "Search query logged")
                }
                .addOnFailureListener { e ->
                    Log.e("Firestore", "Error logging query: ${e.message}")
                }
        }
    }

    fun getChildSearchHistory(childId: String) {
        val searchLogsRef = db.collection("search_logs").document(childId)
        searchLogsRef.addSnapshotListener { document, error ->
            if (error != null) {
                println("Firestore listen failed: ${error.message}")
                return@addSnapshotListener
            }
            if (document != null && document.exists()) {
                val logs = document.get("queryLogs") as? List<String> ?: emptyList()
                _searchLogs.value = logs
            } else {
                _searchLogs.value = emptyList()
                println("No search logs found for child")
            }
        }
    }
}