package com.org.childmonitorparent.common.chats

data class ChatMessage(
    val messageId: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val mediaUrl: String = "",
    val fileType: String = "",
    var status: MessageStatus = MessageStatus.SENDING // Initial state
)

enum class MessageStatus {
    SENDING, // Single gray tick (Message is being sent)
    SENT, // Single gray tick (Message sent to Firebase)
    DELIVERED, // Double gray tick (Message delivered to recipient)
    READ, // Double blue tick (Message read by recipient)
    FAILED // Single red cross (Message failed to send)
}