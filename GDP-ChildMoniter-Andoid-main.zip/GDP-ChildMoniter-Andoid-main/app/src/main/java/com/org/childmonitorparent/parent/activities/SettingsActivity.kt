package com.org.childmonitorparent.parent.activities

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.org.childmonitorparent.R
import com.org.childmonitorparent.auth.viewmodels.AuthViewModel
import com.org.childmonitorparent.child.activities.ChildProfileActivity
import com.org.childmonitorparent.common.utils.DialogHelper
import com.org.childmonitorparent.common.utils.PermissionsHelper
import com.org.childmonitorparent.databinding.ActivitySettingsBinding
import com.org.childmonitorparent.databinding.CustomToolbarBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var customToolbarBinding: CustomToolbarBinding
    private val authViewModel: AuthViewModel by viewModels()
    private var isChild = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        customToolbarBinding = binding.customToolbar

        isChild = intent.getBooleanExtra("isChild", false)
        if (isChild) {
            binding.notificationLayout.visibility = View.GONE
        } else {
            binding.notificationLayout.visibility = View.VISIBLE
        }

        binding.permissionSwitch.setOnCheckedChangeListener { _, isChecked ->
            // Handle switch state change
            if (isChecked) {
                checkPermissions()
            }
        }

        if (PermissionsHelper.hasNotificationPermission(this))
            binding.permissionSwitch.isChecked = true

        setupToolbar()
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            binding.permissionSwitch.isChecked = true
        }
    }

    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                if (!isChild) {
                    println("✅ Notification permission granted")
                    checkPermissions()
                }
            } else {
                if (!isChild) {
                    println("❌ Notification permission denied")
                    binding.permissionSwitch.isChecked = false
                    showSettingsDialog()
                    Toast.makeText(
                        this,
                        "Notification permission is required!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

    private fun setupToolbar() {
        customToolbarBinding = binding.customToolbar
        customToolbarBinding.title.text = getString(R.string.settings)
        customToolbarBinding.rightAction.visibility = View.GONE
        customToolbarBinding.leftAction.setOnClickListener {
            finish()
        }
    }

    fun onChangePassword(view: View) {
        DialogHelper.showChangePasswordDialog(this) { success, currentPassword, newPassword ->
            if (success) {
                // Handle password change success
                authViewModel.changePassword(this, currentPassword, newPassword) {
                    if (it) {
                        Toast.makeText(this, "Password changed successfully", Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        Toast.makeText(this, "Failed to change password", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    fun onLogoutClick(view: View) {
        DialogHelper.showLogoutDialog(this) { success ->
            if (success) {
                authViewModel.userLogout(this)
                finish()
            }
        }
    }

    private fun showSettingsDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permission Required")
            .setMessage("Notification permission is required. Please enable it in Settings.")
            .setPositiveButton("Go to Settings") { _, _ ->
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                startActivity(intent)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun onProfileDetails(view: View) {
        if (isChild) {
            startActivity(Intent(this, ChildProfileActivity::class.java))
        } else {
            startActivity(Intent(this, ParentProfileActivity::class.java))
        }
    }
}