package com.org.childmonitorparent.parent.activities

import android.Manifest
import android.content.Intent
import android.location.Geocoder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.org.childmonitorparent.R
import com.org.childmonitorparent.databinding.ActivityPinLocationBinding
import com.org.childmonitorparent.parent.viewmodels.LocationViewModel
import java.util.Locale

class PinLocationActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var selectedLocation: LatLng? = null
    private var marker: Marker? = null
    private lateinit var binding: ActivityPinLocationBinding
    private lateinit var locationViewModel: LocationViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPinLocationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        locationViewModel = LocationViewModel()

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        requestPermissions()
    }

    private fun requestPermissions() {
        val requestPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
                val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
                if (!granted) {
                    Toast.makeText(this, "Location permission is required!", Toast.LENGTH_SHORT)
                        .show()
                }
            }

        requestPermissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val defaultLocation = LatLng(20.5937, 78.9629)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 15f))

        // Allow user to place pin anywhere on map
        mMap.setOnMapClickListener { latLng ->
            selectedLocation = latLng
            marker?.remove() // Remove previous marker
            marker = mMap.addMarker(MarkerOptions().position(latLng).title("Selected Location"))
            binding.selectedLocation.text = getAddressFromLatLng(latLng)
        }
    }

    fun onDoneClick(view: View) {
        selectedLocation?.let {
            val address = getAddressFromLatLng(it)
            val resultIntent = Intent().apply {
                putExtra("latitude", it.latitude)
                putExtra("longitude", it.longitude)
                putExtra("address", address)
            }
            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }

    private fun getAddressFromLatLng(latLng: LatLng): String {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
        return if (addresses!!.isNotEmpty()) {
            addresses[0].getAddressLine(0) ?: "Unknown Address"
        } else {
            "Unknown Address"
        }
    }
}