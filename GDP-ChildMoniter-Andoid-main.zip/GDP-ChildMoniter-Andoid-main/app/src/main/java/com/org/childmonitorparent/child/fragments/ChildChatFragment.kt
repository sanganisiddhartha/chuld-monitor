package com.org.childmonitorparent.child.fragments

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.org.childmonitorparent.common.calls.CallActivity
import com.org.childmonitorparent.common.chats.ChatAdapter
import com.org.childmonitorparent.common.chats.ChatMessage
import com.org.childmonitorparent.common.chats.ChatViewModel
import com.org.childmonitorparent.common.chats.MessageStatus
import com.org.childmonitorparent.common.chats.VideoPlayerActivity
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.common.utils.ChatsDiffCallback
import com.org.childmonitorparent.common.utils.FileUtils
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.databinding.CustomChatLayoutBinding
import com.org.childmonitorparent.databinding.FragmentChildChatBinding
import com.org.childmonitorparent.parent.models.ChildInfo

class ChildChatFragment : Fragment(), OnClickTypeValue, LifecycleEventObserver {

    private var _binding: FragmentChildChatBinding? = null
    private val binding get() = _binding!!
    private lateinit var customChatLayoutBinding: CustomChatLayoutBinding
    private lateinit var context: Context
    private lateinit var chatAdapter: ChatAdapter
    private val chatViewModel: ChatViewModel by activityViewModels()
    private val sharedViewModel: SharedViewModel<ChildInfo> by activityViewModels()
    private val chatList: MutableList<ChatMessage> = mutableListOf()
    private var chatRoomId: String? = null
    private var receiverId: String? = null
    private var selectedMediaURI: Uri? = null
    private lateinit var childInfo: ChildInfo

    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                selectedMediaURI = it
                val mimeType = requireContext().contentResolver.getType(selectedMediaURI!!)
                val fileType = if (mimeType?.startsWith("image") == true) "image" else "video"
                FileUtils.getFilePath(context, it)
                    ?.let { it1 -> sendTempMessage("", it1, fileType) }
                // Upload selected media file
                chatViewModel.uploadMediaToFirebase(selectedMediaURI!!, fileType) { mediaUrl ->
                    if (mediaUrl != null) {
                        sendMessage("", mediaUrl, fileType)
                    }
                }
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentChildChatBinding.inflate(inflater, container, false)
        customChatLayoutBinding = binding.chatLayout
        context = requireContext()

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        customChatLayoutBinding.callImage.setOnClickListener {
            val intent = Intent(requireContext(), CallActivity::class.java)
            intent.putExtra("roomId", chatRoomId)
            intent.putExtra("name", childInfo.name)
            intent.putExtra("receiverId", receiverId)
            intent.putExtra("callBy", "child")
            startActivity(intent)
        }

        chatAdapter = ChatAdapter(context, chatList, PrefsHelper.getData("userId"), this)
        customChatLayoutBinding.chatList.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = chatAdapter
        }
        chatViewModel.chatList.observe(viewLifecycleOwner) { messages ->
            if (messages.isNotEmpty()) {
                updateMessages(messages)
            }
        }

        sharedViewModel.childInfo.observe(viewLifecycleOwner) { childInfo ->
            childInfo?.let {
                this.childInfo = it
                chatRoomId = "${it.parentId}_${it.childId}"
                receiverId = it.parentId
                chatRoomId?.let { id ->
                    chatViewModel.listenForMessages(id)
                }
            }
        }

        customChatLayoutBinding.attachImage.setOnClickListener {
            galleryLauncher.launch("*/*")
        }

        customChatLayoutBinding.sendMessage.setOnClickListener {
            val messageText = customChatLayoutBinding.messageInput.text.toString()
            if (messageText.isNotEmpty()) {
                sendMessage(messageText, "", "text")
                customChatLayoutBinding.messageInput.text.clear()
            }
        }
    }

    private fun sendTempMessage(messageText: String, mediaUrl: String, fileType: String) {
        val message = if (messageText.isNotEmpty()) {
            ChatMessage(
                "",
                senderId = PrefsHelper.getData("userId"),
                receiverId = receiverId ?: "",
                message = messageText,
                timestamp = System.currentTimeMillis(),
                "",
                "",
                MessageStatus.SENDING
            )
        } else {
            ChatMessage(
                "",
                senderId = PrefsHelper.getData("userId"),
                receiverId = receiverId ?: "",
                message = messageText,
                timestamp = System.currentTimeMillis(),
                mediaUrl,
                fileType,
                MessageStatus.SENDING
            )
        }

        val tempChatList: MutableList<ChatMessage> = mutableListOf()
        tempChatList.addAll(chatList)
        tempChatList.add(message)
        updateMessages(tempChatList)
    }

    private fun sendMessage(
        messageText: String,
        mediaUrl: String,
        fileType: String
    ) {
        val message = if (messageText.isNotEmpty()) {
            ChatMessage(
                "",
                senderId = PrefsHelper.getData("userId"),
                receiverId = receiverId ?: "",
                message = messageText,
                timestamp = System.currentTimeMillis(),
                "",
                ""
            )
        } else {
            ChatMessage(
                "",
                senderId = PrefsHelper.getData("userId"),
                receiverId = receiverId ?: "",
                message = messageText,
                timestamp = System.currentTimeMillis(),
                mediaUrl,
                fileType
            )
        }

        chatRoomId?.let { it1 ->
            chatViewModel.sendMessage(it1, message) {
                println("✅ Message sent")
            }
        }
    }

    private fun updateMessages(newList: List<ChatMessage>) {
        val diffCallback = ChatsDiffCallback(this.chatList, newList)
        val diffResult = DiffUtil.calculateDiff(diffCallback)

        this.chatList.clear()
        this.chatList.addAll(newList)
        diffResult.dispatchUpdatesTo(chatAdapter)
        customChatLayoutBinding.chatList.post {
            if (chatList.isNotEmpty())
                customChatLayoutBinding.chatList.smoothScrollToPosition(chatList.size - 1) // 🔥 Smooth Scroll to Bottom
        }
    }

    override fun onClick(position: Int, type: String, value: String) {
        startActivity(Intent(requireContext(), VideoPlayerActivity::class.java).apply {
            this.putExtra("video_url", value)
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycle.addObserver(this) // Attach lifecycle observer
    }

    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        when (event) {
            Lifecycle.Event.ON_RESUME -> {
                chatViewModel.setChatScreenActive(true)
                chatRoomId?.let {
                    chatViewModel.listenForMessages(it)
                }
                PrefsHelper.saveData("childChatActive", "true")
                println("✅ ChildChatFragment is ACTIVE")
            }
            Lifecycle.Event.ON_PAUSE -> {
                chatViewModel.setChatScreenActive(false)
                PrefsHelper.saveData("childChatActive", "false")
                println("❌ ChildChatFragment is INACTIVE")
            }
            else -> {}
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}