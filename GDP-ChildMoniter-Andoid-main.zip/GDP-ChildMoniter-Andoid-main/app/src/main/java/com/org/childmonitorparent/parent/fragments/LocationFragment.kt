package com.org.childmonitorparent.parent.fragments

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.databinding.FragmentLocationBinding
import com.org.childmonitorparent.parent.models.ChildInfo
import com.org.childmonitorparent.parent.viewmodels.LocationViewModel

class LocationFragment : Fragment(), OnMapReadyCallback {

    private var _binding: FragmentLocationBinding? = null
    private val binding get() = _binding!!
    private lateinit var mMap: GoogleMap
    private val locationViewModel: LocationViewModel by viewModels()
    private val sharedViewModel: SharedViewModel<ChildInfo> by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLocationBinding.inflate(inflater, container, false)

        // Initialize Map Fragment correctly
        val mapFragment = childFragmentManager
            .findFragmentById(R.id.map) as? SupportMapFragment
        mapFragment?.getMapAsync(this)

        // Observe location updates from ViewModel
        locationViewModel.childLocation.observe(viewLifecycleOwner) { location ->
            location?.let {
                updateMapLocation(it.latitude, it.longitude)
            }
        }

        sharedViewModel.childInfo.observe(viewLifecycleOwner) { childInfo ->
            childInfo?.childId?.let { locationViewModel.listenToChildLocation(it) }
        }

        return binding.root
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Enable My Location button if permission is granted
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        }

        // Default location (Sydney) before getting real-time updates
        val defaultLocation = LatLng(20.5937, 78.9629)
        updateMapLocation(defaultLocation.latitude, defaultLocation.longitude)
    }

    private fun updateMapLocation(latitude: Double, longitude: Double) {
        val newLocation = LatLng(latitude, longitude)
        mMap.clear() // Remove old markers
        mMap.addMarker(
            MarkerOptions().position(newLocation).title("Current Location").visible(true)
        )
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(newLocation, 15f))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
