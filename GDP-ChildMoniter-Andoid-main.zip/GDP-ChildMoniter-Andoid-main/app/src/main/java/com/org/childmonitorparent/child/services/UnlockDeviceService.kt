package com.org.childmonitorparent.child.services

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.org.childmonitorparent.child.activities.ChildMainActivity

class UnlockDeviceService : Service() {
    override fun onCreate() {
        super.onCreate()
        val notification = createNotification()
        startForeground(1, notification) // Required for Foreground Service
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        unlockDevice()
        return START_NOT_STICKY
    }

    private fun unlockDevice() {
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (keyguardManager.isKeyguardLocked) {
                val activityIntent = Intent(this, ChildMainActivity::class.java)
                activityIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(activityIntent) // Open MainActivity to handle UI unlock
            }
        }
    }

    private fun createNotification(): Notification {
        val channelId = "unlock_channel"
        val channelName = "Unlock Service"

        // 🔹 Ensure Notification Channel is Created (Android 8+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_LOW // Set importance to low to avoid sound/vibration
            )
            notificationManager?.createNotificationChannel(channel)
        }

        // 🔹 Create Notification
        val notificationIntent = Intent(this, ChildMainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Unlocking Device")
            .setContentText("Unlocking your device securely...")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW) // Low priority to avoid unnecessary alerts
            .build()
    }


    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
