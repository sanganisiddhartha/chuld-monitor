package com.org.childmonitorparent.child.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.utils.StaticLists.ageList
import com.org.childmonitorparent.common.utils.StaticLists.genderList
import com.org.childmonitorparent.common.utils.StaticLists.heightList
import com.org.childmonitorparent.common.utils.StaticLists.weightList
import com.org.childmonitorparent.databinding.ActivityChildProfileBinding
import com.org.childmonitorparent.databinding.CustomToolbarBinding
import com.org.childmonitorparent.parent.activities.PinLocationActivity
import com.org.childmonitorparent.parent.models.ChildInfo
import com.org.childmonitorparent.parent.viewmodels.AddChildViewModel

class ChildProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChildProfileBinding
    private lateinit var customToolbarBinding: CustomToolbarBinding
    private val addChildViewModel: AddChildViewModel by viewModels()
    private lateinit var childInfo: ChildInfo
    private var selectedAge = "Age"
    private var selectedGender = "Gender"
    private var selectedHeight = "CM"
    private var selectedWeight = "KG"
    private var homeLocation = ""
    private var schoolLocation = ""
    private var locationSelection = "home"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChildProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        customToolbarBinding = binding.toolBar
        customToolbarBinding.title.text = getString(R.string.profile_details)
        customToolbarBinding.leftAction.setOnClickListener {
            finish()
        }
        customToolbarBinding.rightAction.visibility = View.VISIBLE
        customToolbarBinding.rightAction.setImageResource(R.drawable.ic_check)
        customToolbarBinding.rightAction.imageTintList = getColorStateList(R.color.black)
        customToolbarBinding.rightAction.setOnClickListener {
            if (selectedAge == "Age" || selectedGender == "Gender" || selectedHeight == "CM" || selectedWeight == "KG" || binding.etSchoolName.text.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                childInfo.selectedAge = selectedAge
                childInfo.selectedGender = selectedGender
                childInfo.selectedHeight = selectedHeight
                childInfo.selectedWeight = selectedWeight
                childInfo.schoolName = binding.etSchoolName.text.toString()
                childInfo.homeLocation = homeLocation
                childInfo.schoolLocation = schoolLocation
                childInfo.homeAddress = binding.tvLocation.text.toString()
                childInfo.schoolAddress = binding.tvSchoolLocation.text.toString()
                updateChildProfile()
            }
        }

        binding.pinHomeLocation.setOnClickListener {
            locationSelection = "home"
            locationPickerLauncher.launch(Intent(this, PinLocationActivity::class.java))
        }
        binding.pinSchoolLocation.setOnClickListener {
            locationSelection = "school"
            locationPickerLauncher.launch(Intent(this, PinLocationActivity::class.java))
        }

        addChildViewModel.childInfo.observe(this) {
            it?.let {
                childInfo = it
                childInfo.childId = it.childId
                selectedAge = it.selectedAge
                selectedGender = it.selectedGender
                selectedHeight = it.selectedHeight
                selectedWeight = it.selectedWeight
                homeLocation = childInfo.homeLocation
                schoolLocation = childInfo.schoolLocation
                setChildProfileData()
            }
        }
        addChildViewModel.getChildInfo()
    }

    private fun updateChildProfile() {
        addChildViewModel.updateChildInfo(this, childInfo) {
            if (it) {
                Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Failed to update profile", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setChildProfileData() {
        binding.name.text = childInfo.name
        binding.email.text = PrefsHelper.getData("userEmail")
        binding.tvLocation.text = childInfo.homeAddress
        binding.tvSchoolLocation.text = childInfo.schoolAddress
        binding.etSchoolName.setText(childInfo.schoolName)

        // Ensure spinners handle selected values properly
        setSpinnerSelection(binding.spinnerAge, selectedAge, ageList) { selectedAge = it }
        setSpinnerSelection(binding.spinnerGender, selectedGender, genderList) {
            selectedGender = it
        }
        setSpinnerSelection(binding.spinnerHeight, selectedHeight, heightList) {
            selectedHeight = it
        }
        setSpinnerSelection(binding.spinnerWeight, selectedWeight, weightList) {
            selectedWeight = it
        }
    }

    // 🔹 Helper function to set spinner selection safely
    private fun setSpinnerSelection(
        spinner: Spinner,
        value: String?,
        items: List<String>,
        onItemSelected: (String) -> Unit
    ) {

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        spinner.adapter = adapter

        value?.let {
            for (i in 0 until adapter.count) {
                if (adapter.getItem(i).toString() == value) {
                    spinner.setSelection(i)
                    break
                }
            }
        }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = items[position]
                if (position != 0) { // Avoid selecting default text
                    onItemSelected(selectedItem)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private val locationPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val latitude = data?.getDoubleExtra("latitude", 0.0) ?: 0.0
            val longitude = data?.getDoubleExtra("longitude", 0.0) ?: 0.0
            val address = data?.getStringExtra("address") ?: "Unknown Address"
            if (locationSelection == "home") {
                homeLocation = "$latitude,$longitude"
                binding.tvLocation.text = address
            } else {
                schoolLocation = "$latitude,$longitude"
                binding.tvSchoolLocation.text = address
            }
        }
    }
}