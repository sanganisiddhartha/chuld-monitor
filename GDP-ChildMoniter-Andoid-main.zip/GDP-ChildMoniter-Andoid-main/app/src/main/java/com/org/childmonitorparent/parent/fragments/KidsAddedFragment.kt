package com.org.childmonitorparent.parent.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import com.org.childmonitorparent.child.activities.ChildMainActivity
import com.org.childmonitorparent.databinding.FragmentKidsAddedBinding
import com.org.childmonitorparent.parent.activities.KidsListActivity
import com.org.childmonitorparent.parent.viewmodels.AddChildViewModel

class KidsAddedFragment : Fragment() {

    private var _binding: FragmentKidsAddedBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private val addChildViewModel: AddChildViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentKidsAddedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnManageNow.setOnClickListener {
            startActivity(Intent(requireContext(), ChildMainActivity::class.java))
            /*val addChildInfo = addChildViewModel.getAddChildInfo()?: AddChildInfo("", "", "", "", "", "", "", "")
            addChildViewModel.saveChildInfo(addChildInfo) { success ->
                if (success) startActivity(Intent(requireContext(), KidsLocationActivity::class.java))
                else Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT)
                    .show()
            }*/
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}