package com.org.childmonitorparent.common.models

data class LogItem(
    val name: String,         // Caller Name, Contact Name, or Sender
    val number: String,        // Caller Name, Contact Name, or Sender
    val subtitle: String,     // Call Type, Message Text, or Phone Number
    val extraInfo: String,    // Call Duration or Message Content
    val timestamp: String,    // Formatted Date/Time
    val logType: LogType      // Enum for Call, Message, Contact
) {
    constructor() : this("", "", "", "", "", LogType.CALL)
}

enum class LogType(val type: Int) {
    CALL(0),
    MESSAGE(1),
    CONTACT(2)
}