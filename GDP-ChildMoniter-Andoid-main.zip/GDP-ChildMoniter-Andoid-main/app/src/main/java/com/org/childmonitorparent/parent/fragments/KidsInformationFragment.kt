package com.org.childmonitorparent.parent.fragments

import android.R
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.org.childmonitorparent.auth.models.User
import com.org.childmonitorparent.databinding.FragmentKidsInformationBinding
import com.org.childmonitorparent.parent.activities.PinLocationActivity
import com.org.childmonitorparent.parent.models.AddChildInfo
import com.org.childmonitorparent.parent.viewmodels.AddChildViewModel
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.utils.StaticLists.ageList
import com.org.childmonitorparent.common.utils.StaticLists.genderList
import com.org.childmonitorparent.common.utils.StaticLists.heightList
import com.org.childmonitorparent.common.utils.StaticLists.weightList
import com.org.childmonitorparent.common.viewmodels.SharedViewModel

class KidsInformationFragment : Fragment() {

    private var _binding: FragmentKidsInformationBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private var selectedAge = "Age"
    private var selectedGender = "Gender"
    private var selectedHeight = "CM"
    private var selectedWeight = "KG"
    private lateinit var addChildInfo: AddChildInfo
    private val addChildViewModel: AddChildViewModel by activityViewModels()
    private val sharedViewModel: SharedViewModel<User> by activityViewModels()
    private lateinit var homeLocation: String

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentKidsInformationBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupSpinner(binding.spinnerAge, ageList) { selectedAge = it }
        setupSpinner(binding.spinnerGender, genderList) { selectedGender = it }
        setupSpinner(binding.spinnerHeight, heightList) { selectedHeight = it }
        setupSpinner(binding.spinnerWeight, weightList) { selectedWeight = it }

        binding.pinHomeLocation.setOnClickListener {
            val intent = Intent(requireContext(), PinLocationActivity::class.java)
            locationPickerLauncher.launch(intent)
        }

        binding.btnContinue.setOnClickListener {
            val name = binding.etName.text.toString()
            val location = binding.tvLocation.text.toString()
            if (name.isEmpty() || location.isEmpty() || selectedAge.isEmpty() || selectedAge == "Age" || selectedGender.isEmpty() || selectedGender == "Gender" || selectedHeight.isEmpty() || selectedHeight == "CM" || selectedWeight.isEmpty() || selectedWeight == "KG") {
                Toast.makeText(requireContext(), "Please select all fields", Toast.LENGTH_SHORT)
                    .show()
            } else {
                addChildInfo = AddChildInfo(
                    binding.etName.text.toString(),
                    binding.tvLocation.text.toString(),
                    selectedAge,
                    selectedGender,
                    selectedHeight,
                    selectedWeight,
                    "",
                    "",
                    sharedViewModel.childInfo.value?.parentId ?: "",
                    sharedViewModel.childInfo.value?.userId ?: "",
                    homeLocation,
                    ""
                )
                addChildViewModel.setAddChildInfo(addChildInfo)
                findNavController().navigate(com.org.childmonitorparent.R.id.action_secondFragment_to_thirdFragment)
            }
        }
        binding.btnCancel.setOnClickListener {
            findNavController().navigate(com.org.childmonitorparent.R.id.action_secondFragment_to_firstFragment)
        }
    }

    private val locationPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val latitude = data?.getDoubleExtra("latitude", 0.0) ?: 0.0
            val longitude = data?.getDoubleExtra("longitude", 0.0) ?: 0.0
            homeLocation = "$latitude,$longitude"
            val address = data?.getStringExtra("address") ?: "Unknown Address"
            binding.tvLocation.text = "$address"
        }
    }

    private fun setupSpinner(
        spinner: Spinner,
        items: List<String>,
        onItemSelected: (String) -> Unit
    ) {
        val adapter = ArrayAdapter(requireContext(), R.layout.simple_spinner_dropdown_item, items)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = items[position]
                if (position != 0) { // Avoid selecting default text
                    onItemSelected(selectedItem)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
