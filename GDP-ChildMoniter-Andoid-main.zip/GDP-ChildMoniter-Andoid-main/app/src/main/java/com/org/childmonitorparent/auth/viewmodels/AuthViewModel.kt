package com.org.childmonitorparent.auth.viewmodels

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.firebase.Firebase
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.firestore
import com.org.childmonitorparent.auth.activities.LoginActivity
import com.org.childmonitorparent.auth.models.User
import com.org.childmonitorparent.common.utils.PasswordUtils
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.utils.ProgressDialogHelper
import com.org.childmonitorparent.parent.models.ChildInfo

class AuthViewModel : ViewModel() {
    private val auth = Firebase.auth
    private val user = auth.currentUser
    private val db = Firebase.firestore
    private val userEmail = PrefsHelper.getData("userEmail")
    private var userPassword = PrefsHelper.getData("userPassword")
    private val passwordSalt = PrefsHelper.getData("passwordSalt")
    private var _userDetails = MutableLiveData<User>()
    val userDetails: MutableLiveData<User> = _userDetails

    fun forgotPassword(email: String, onComplete: (Boolean) -> Unit) {
        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            }
            .addOnFailureListener {
                onComplete(false)
            }
    }

    fun changePassword(
        context: Context,
        currentPassword: String,
        newPassword: String,
        onComplete: (Boolean) -> Unit
    ) {
        ProgressDialogHelper.showProgressDialog(context, "Updating password...")
        // 🔹 Get the user's current credentials (Email & Password)
        val credential = EmailAuthProvider.getCredential(userEmail, currentPassword)
        user?.reauthenticate(credential)
            ?.addOnCompleteListener { reauthTask ->
                if (reauthTask.isSuccessful) {
                    if (PasswordUtils.verifyPassword(currentPassword, userPassword, passwordSalt)) {
                        val newSalt = PasswordUtils.generateSalt()
                        val newHashedPassword = PasswordUtils.hashPassword(newPassword, newSalt)
                        // 🔹 Now update password
                        user.updatePassword(newPassword)
                            .addOnCompleteListener { task ->
                                ProgressDialogHelper.hideProgressDialog()
                                if (task.isSuccessful) {
                                    PrefsHelper.saveData("userPassword", newHashedPassword)
                                    updateUserPassword(user.uid, newHashedPassword) {
                                        if (it)
                                            onComplete(true)
                                        else onComplete(false)
                                    }
                                } else {
                                    println(
                                        "❌ Failed to update password: ${task.exception?.message}"
                                    )
                                    onComplete(false)
                                }
                            }
                    } else {
                        Toast.makeText(context, "Incorrect current password", Toast.LENGTH_SHORT)
                            .show()
                        ProgressDialogHelper.hideProgressDialog()
                        onComplete(false)
                    }
                } else {
                    println(
                        "❌ Reauthentication failed: ${reauthTask.exception?.message}"
                    )
                    ProgressDialogHelper.hideProgressDialog()
                    onComplete(false)
                }
            }
    }

    private fun updateUserPassword(
        userId: String,
        newPassword: String,
        onSuccess: (Boolean) -> Unit
    ) {
        db.collection("user").document(userId)
            .update("password", newPassword)
            .addOnSuccessListener {
                onSuccess(true) // Success
            }
            .addOnFailureListener { e ->
                onSuccess(false)
            }
    }

    fun checkParentEmailExists(parentEmail: String, onComplete: (Boolean, String) -> Unit) {
        db.collection("user")
            .whereEqualTo("userType", "Parent")
            .whereEqualTo("email", parentEmail).get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    onComplete(false, "")
                } else {
                    onComplete(true, "${documents.documents[0].id}")
                }
            }
            .addOnFailureListener {
                onComplete(false, "")
            }
    }

    fun signUp(context: Context, user: User, onComplete: (Boolean) -> Unit) {
        ProgressDialogHelper.showProgressDialog(context, "Signing up...")
        auth.createUserWithEmailAndPassword(user.email, user.password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val currentUser = auth.currentUser
                    currentUser?.let {
                        if (user.userType == "Parent")
                            user.parentId = it.uid

                        user.userId = it.uid
                        saveUser(it.uid, user, onComplete)
                    }
                } else {
                    ProgressDialogHelper.hideProgressDialog()
                    onComplete(false)
                }
            }
            .addOnFailureListener { exception ->
                ProgressDialogHelper.hideProgressDialog()
                Log.d("AuthViewModel", "Sign up failed: ${exception.message}")
                onComplete(false)
            }
    }

    private fun saveUser(userId: String, user: User, onComplete: (Boolean) -> Unit) {

        val salt = PasswordUtils.generateSalt()
        user.passwordSalt = salt
        val hashedPassword = PasswordUtils.hashPassword(user.password, salt)
        user.password = hashedPassword

        db.collection("user").document(userId)
            .set(user)
            .addOnSuccessListener { documentReference ->
                // Handle success
                ProgressDialogHelper.hideProgressDialog()
                PrefsHelper.saveData("userType", user.userType)
                PrefsHelper.saveData("userId", userId)
                PrefsHelper.saveData("userEmail", user.email)
                PrefsHelper.saveData("userPassword", user.password)
                PrefsHelper.saveData("passwordSalt", user.passwordSalt)
                PrefsHelper.saveData("userName", user.username ?: "")
                PrefsHelper.saveData("parentId", user.parentId ?: "")
                onComplete(true)
            }
            .addOnFailureListener { e ->
                // Handle failure
                ProgressDialogHelper.hideProgressDialog()
                onComplete(false)
            }
    }

    fun updateUser(context: Context, userId: String, user: User, onComplete: (Boolean) -> Unit) {
        ProgressDialogHelper.showProgressDialog(context, "Updating profile...")
        val phoneNumber = mapOf(
            "phone" to user.phone
        )

        db.collection("user").document(userId)
            .update(phoneNumber)
            .addOnSuccessListener { documentReference ->
                // Handle success
                ProgressDialogHelper.hideProgressDialog()
                onComplete(true)
            }
            .addOnFailureListener { e ->
                // Handle failure
                ProgressDialogHelper.hideProgressDialog()
                onComplete(false)
            }
    }

    fun login(context: Context, email: String, password: String, onComplete: (Boolean) -> Unit) {
        ProgressDialogHelper.showProgressDialog(context, "Logging in...")
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    user?.let {
                        getUserFromId(it.uid, onComplete)
                    }
                } else {
                    onComplete(false)
                }
            }
            .addOnFailureListener { exception ->
                ProgressDialogHelper.hideProgressDialog()
                Log.d("AuthViewModel", "Login failed: ${exception.message}")
                onComplete(false)
            }
    }

    fun getUserFromId(userId: String, onComplete: (Boolean) -> Unit) {
        db.collection("user").document(userId)
            .get()
            .addOnSuccessListener { document ->
                ProgressDialogHelper.hideProgressDialog()
                if (document != null) {
                    _userDetails.value = document.toObject(User::class.java)
                    PrefsHelper.saveData("userType", document.getString("userType") ?: "")
                    PrefsHelper.saveData("userId", userId)
                    PrefsHelper.saveData("userEmail", document.getString("email") ?: "")
                    PrefsHelper.saveData("userPassword", document.getString("password") ?: "")
                    PrefsHelper.saveData("passwordSalt", document.getString("passwordSalt") ?: "")
                    PrefsHelper.saveData("userName", document.getString("username") ?: "")
                    PrefsHelper.saveData("parentId", document.getString("parentId") ?: "")
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            }
            .addOnFailureListener { exception ->
                ProgressDialogHelper.hideProgressDialog()
                Log.d("AuthViewModel", "Error getting user: ${exception.message}")
            }
    }

    fun userLogout(context: Context) {
        auth.signOut()
        PrefsHelper.clearData(context)
        context.startActivity(Intent(context, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
    }

    /*// Function to handle Google Sign-Up
    fun googleSignUp(googleSignInClient: GoogleSignInClient, data: Intent?, onComplete: (Boolean, String?) -> Unit) {
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            // Google Sign-In was successful, authenticate with Firebase
            val account = task.getResult(ApiException::class.java)
            if (account != null) {
                firebaseAuthWithGoogle(account, onComplete)
            } else {
                onComplete(false, "Google Sign-In failed: Account is null")
            }
        } catch (e: ApiException) {
            // Google Sign-In failed
            onComplete(false, "Google Sign-In failed: ${e.message}")
        }
    }*/

    // Function to authenticate with Firebase using Google credentials
    private fun firebaseAuthWithGoogle(
        account: GoogleSignInAccount,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Sign-in success
                    onComplete(true, null)
                } else {
                    // Sign-in failed
                    onComplete(
                        false,
                        "Firebase authentication failed: ${task.exception?.message}"
                    )
                }
            }
    }
}