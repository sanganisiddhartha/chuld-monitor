package com.org.childmonitorparent.auth.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.org.childmonitorparent.child.activities.ChildMainActivity
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.parent.activities.KidsListActivity

class SplashActivity : AppCompatActivity() {
    private lateinit var context: Context
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        context = this
        checkLoginStatus()
    }

    private fun checkLoginStatus() {
        val intent =
            if (PrefsHelper.getData("userId").isNotEmpty() && PrefsHelper.getData("userType")
                    .isNotEmpty()
            ) {
                if (PrefsHelper.getData("userType") == "Parent") Intent(
                    context,
                    KidsListActivity::class.java
                ) else Intent(context, ChildMainActivity::class.java)
            } else {
                Intent(context, LoginActivity::class.java)
            }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        finish()
    }
}