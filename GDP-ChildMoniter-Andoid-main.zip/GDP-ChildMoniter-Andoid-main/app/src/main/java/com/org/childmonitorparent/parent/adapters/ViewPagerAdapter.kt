package com.org.childmonitorparent.parent.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.org.childmonitorparent.parent.fragments.ChildLinkPageFragment
import com.org.childmonitorparent.parent.fragments.KidsAddedFragment
import com.org.childmonitorparent.parent.fragments.KidsInformationFragment
import com.org.childmonitorparent.parent.fragments.SchoolInformationFragment

class ViewPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    override fun getItemCount(): Int = 4

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> ChildLinkPageFragment()
            1 -> KidsInformationFragment()
            2 -> SchoolInformationFragment()
            3 -> KidsAddedFragment()
            else -> ChildLinkPageFragment()
        }
    }
}
