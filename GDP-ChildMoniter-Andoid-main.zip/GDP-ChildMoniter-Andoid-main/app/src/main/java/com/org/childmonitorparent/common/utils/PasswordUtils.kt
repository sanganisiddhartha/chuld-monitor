package com.org.childmonitorparent.common.utils

import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import android.util.Base64
import javax.crypto.spec.PBEKeySpec

object PasswordUtils {

    private const val ITERATIONS = 10000
    private const val KEY_LENGTH = 256

    // Generate a random salt
    fun generateSalt(): String {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        return Base64.encodeToString(salt, Base64.NO_WRAP)
    }

    // Hash password using PBKDF2 algorithm
    fun hashPassword(password: String, salt: String): String {
        val spec = PBEKeySpec(password.toCharArray(), Base64.decode(salt, Base64.NO_WRAP), ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.NO_WRAP)
    }

    // Verify if entered password matches stored hash
    fun verifyPassword(enteredPassword: String, storedHash: String, salt: String): Boolean {
        val newHash = hashPassword(enteredPassword, salt)
        return newHash == storedHash
    }
}
