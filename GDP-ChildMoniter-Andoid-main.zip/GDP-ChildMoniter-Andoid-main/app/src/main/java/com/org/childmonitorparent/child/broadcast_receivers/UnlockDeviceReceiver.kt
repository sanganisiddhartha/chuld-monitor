package com.org.childmonitorparent.child.broadcast_receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Build.VERSION
import androidx.annotation.RequiresApi
import com.org.childmonitorparent.child.services.UnlockDeviceService

@RequiresApi(Build.VERSION_CODES.O)
class UnlockDeviceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val unlockIntent = Intent(context, UnlockDeviceService::class.java)
        context.startForegroundService(unlockIntent)
    }
}
