package com.org.childmonitorparent.child.viewmodels

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.org.childmonitorparent.child.models.PermissionItem

class PermissionsViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()
    private val _childPermissions = MutableLiveData<List<PermissionItem>>()
    val childPermissions: MutableLiveData<List<PermissionItem>> = _childPermissions
    private var childPermissionsListener: ListenerRegistration? = null


    fun saveChildPermissions(childId: String, permissionsList: List<PermissionItem>) {
        if (permissionsList.isEmpty()) {
            Log.e("Firestore", "No permission to save")
            return
        }

        val docRef = db.collection("child_permissions").document(childId) // 🔥 Store under childId

        // ✅ Store apps list inside Firestore document
        val data = mapOf("permissions_list" to permissionsList)

        docRef.set(data, SetOptions.merge()) // 🔥 Merge instead of overwrite
            .addOnSuccessListener {
                Log.d("Firestore", "All permissions saved and synced in real-time")
                getChildPermissions(childId)
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error saving apps", e)
            }
    }

    fun getChildPermissions(childId: String) {
        val childPermissionsRef = db.collection("child_permissions").document(childId)

        // Remove old listener if it exists (optional)
        childPermissionsListener?.remove()

        // 🔹 Listen for real-time updates
        childPermissionsListener = childPermissionsRef.addSnapshotListener { document, error ->
            if (error != null) {
                println("Firestore listen failed: ${error.message}")
                return@addSnapshotListener
            }

            if (document != null && document.exists()) {
                val permissionsList =
                    document.get("permissions_list") as? List<HashMap<String, Any>> ?: emptyList()

                val childPermissions = permissionsList.mapNotNull { data ->
                    try {
                        PermissionItem(
                            permission = data["permission"] as? String ?: "",
                            label = data["label"] as? String ?: "",
                            isGranted = data["granted"] as? Boolean ?: false
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        null
                    }
                }
                _childPermissions.value = childPermissions // ✅ LiveData updates automatically
            } else {
                _childPermissions.value = emptyList()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        childPermissionsListener?.remove()
    }
}