package com.org.childmonitorparent.parent.viewmodels

import android.location.Location
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore

class LocationViewModel() : ViewModel() {
    private val firestore = FirebaseFirestore.getInstance()
    private val _childLocation = MutableLiveData<Location>()
    val childLocation: LiveData<Location> = _childLocation

    fun listenToChildLocation(childId: String) {
        firestore.collection("locations").document(childId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    println("Error fetching location: ${error.message}")
                    return@addSnapshotListener
                }

                snapshot?.let {
                    val latitude = it.getDouble("latitude")
                    val longitude = it.getDouble("longitude")

                    if (latitude != null && longitude != null) {
                        val location = Location("").apply {
                            this.latitude = latitude
                            this.longitude = longitude
                        }
                        _childLocation.postValue(location)
                    }
                }
            }
    }
}