package com.org.childmonitorparent.child.workmanagers

import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.viewmodels.AppsViewModel

class DeviceAppsWorker(val context: Context, params: WorkerParameters) : Worker(context, params) {

    private val appsViewModel = AppsViewModel(context)
    private val childId = PrefsHelper.getData("userId")

    @RequiresApi(Build.VERSION_CODES.O)
    override fun doWork(): Result {
        getChildApps()
        return Result.success()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun getChildApps() {
        val appsList = appsViewModel.getUserInstalledApps(context)
        println("appsList: ${appsList.size}")
        appsViewModel.saveChildApps(childId, appsList)
    }
}