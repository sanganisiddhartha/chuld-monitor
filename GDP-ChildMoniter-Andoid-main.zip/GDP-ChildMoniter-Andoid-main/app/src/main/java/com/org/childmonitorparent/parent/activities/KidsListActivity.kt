package com.org.childmonitorparent.parent.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.common.utils.DialogHelper.showLockDialog
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.common.utils.ServiceHelper
import com.org.childmonitorparent.databinding.ActivityKidsListBinding
import com.org.childmonitorparent.databinding.CustomToolbarBinding
import com.org.childmonitorparent.parent.adapters.KidsAdapter
import com.org.childmonitorparent.parent.models.ChildInfo
import com.org.childmonitorparent.parent.viewmodels.AddChildViewModel

class KidsListActivity : AppCompatActivity(), OnClickTypeValue {

    private lateinit var binding: ActivityKidsListBinding
    private lateinit var customToolbarBinding: CustomToolbarBinding
    private lateinit var childAdapter: KidsAdapter
    private val childList = mutableListOf<ChildInfo>()
    private val childViewModel: AddChildViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityKidsListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerview()

        // Observe real-time child list updates
        observeRealTimeChildUpdates()

        // Observe lock action change
        childViewModel.isLockActionChanged.observe(this) { isLocked ->
            if (isLocked) {
                getKidsData(false)
            }
        }
        getKidsData(true)
        ServiceHelper.startCallService(this)
    }

    private fun setupToolbar() {
        customToolbarBinding = binding.customToolbar
        customToolbarBinding.leftAction.visibility = View.GONE
        customToolbarBinding.title.text = "Hi, ${PrefsHelper.getData("userName").uppercase()}"
        customToolbarBinding.title.textSize = 18.toFloat()
        customToolbarBinding.rightAction.setImageResource(R.drawable.ic_settings)
        customToolbarBinding.rightAction.visibility = View.VISIBLE
        customToolbarBinding.rightAction.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java).putExtra("isChild", false))
        }
    }

    private fun setupRecyclerview() {
        binding.kidsRecyclerView.layoutManager = LinearLayoutManager(this)
        childAdapter = KidsAdapter(this, childList)
        binding.kidsRecyclerView.adapter = childAdapter
    }

    private fun getKidsData(showDialog: Boolean) {
        childViewModel.getAllChild(this, showDialog)
    }

    /**
     * Observes real-time child data updates from Firestore.
     * Updates UI automatically when child data changes.
     */
    private fun observeRealTimeChildUpdates() {
        childViewModel.childList.observe(this) { newList ->
            if (!childList.containsAll(newList) || childList.size != newList.size) {
                childList.clear()
                childList.addAll(newList)
                childAdapter.notifyDataSetChanged()
            }
        }
    }

    fun onAddNewChildClicked(view: View) {
        startActivity(Intent(this, ChildLinkActivity::class.java))
    }

    private fun lockDialog(position: Int, lock: Boolean) {
        showLockDialog(this) { saveData, lockTime ->
            if (saveData) {
                val childId = childList[position].childId
                childViewModel.sendLockRequest(childId, lock, lockTime)
            } else {
                childAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun unLockDevice(position: Int) {
        val childId = childList[position].childId
        childViewModel.sendLockRequest(childId, false, null)
    }

    private fun openChildDetails(position: Int) {
        val intent = Intent(this, ChildDetailsActivity::class.java)
        intent.putExtra("childInfo", childList[position])
        startActivity(intent)
    }

    override fun onClick(position: Int, type: String, value: String) {
        when (type) {
            "lock_device_true" -> lockDialog(position, true)
            "lock_device_false" -> unLockDevice(position)
            "kid_details" -> openChildDetails(position)
        }
    }
}
