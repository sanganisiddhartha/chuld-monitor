package com.org.childmonitorparent.common.calls

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.facebook.react.modules.core.PermissionListener
import com.org.childmonitorparent.R
import com.org.childmonitorparent.common.utils.PrefsHelper
import com.org.childmonitorparent.databinding.ActivityCallBinding
import org.jitsi.meet.sdk.*

class CallActivity : AppCompatActivity(), JitsiMeetActivityInterface {

    private lateinit var binding: ActivityCallBinding
    private val callViewModel: CallViewModel by viewModels()
    private var isMuted = false
    private lateinit var roomId: String
    private lateinit var name: String
    private lateinit var receiverId: String
    private lateinit var callBy: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCallBinding.inflate(layoutInflater)
        setContentView(binding.root)
        roomId = intent.getStringExtra("roomId") ?: ""
        name = intent.getStringExtra("name") ?: ""
        receiverId = intent.getStringExtra("receiverId") ?: ""
        val callBy = intent.getStringExtra("callBy") ?: ""
        if (callBy == "parent") {
            this.callBy = name
        }else {
            this.callBy = PrefsHelper.getData("parentName")
        }

        binding.tvCallerName.text = this.callBy

        binding.btnMute.setOnClickListener {
            isMuted = !isMuted
            //JitsiCallManager.toggleMute(isMuted)
            binding.btnMute.setImageResource(if (isMuted) R.drawable.ic_mic_off else R.drawable.ic_mic)
        }
        binding.btnEndCall.setOnClickListener {
            JitsiCallManager.endCall()
            callViewModel.saveCall(roomId, "ended", PrefsHelper.getData("userName"), receiverId)
            finish()
        }

        callViewModel.isCallActive.observe(this) { isActive ->
            if (isActive)
                binding.callEndLayout.visibility = View.VISIBLE
            else finish()
        }

        startCall()
        callViewModel.listenForCalls(roomId)
    }

    private fun startCall() {
        JitsiCallManager.startCall(this, roomId)
        callViewModel.saveCall(roomId, "active", PrefsHelper.getData("userName"), receiverId)
    }

    override fun onDestroy() {
        super.onDestroy()
        JitsiMeetActivityDelegate.onHostDestroy(this)
    }

    override fun onResume() {
        super.onResume()
        JitsiMeetActivityDelegate.onHostResume(this)
    }

    override fun onPause() {
        super.onPause()
        JitsiMeetActivityDelegate.onHostPause(this)
    }

    override fun onBackPressed() {
        JitsiMeetActivityDelegate.onBackPressed()
        super.onBackPressed()
    }

    override fun requestPermissions(p0: Array<out String>?, p1: Int, p2: PermissionListener?) {
        TODO("Not yet implemented")
    }
}