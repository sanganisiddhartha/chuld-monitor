package com.org.childmonitorparent.common.interfaces

interface OnClickTypeValue {
    fun onClick(position: Int, type: String, value: String)
}