package com.org.childmonitorparent.parent.fragments

import LogAdapter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.org.childmonitorparent.common.interfaces.OnClickTypeValue
import com.org.childmonitorparent.databinding.FragmentMessageLogBinding
import com.org.childmonitorparent.common.models.LogItem
import com.org.childmonitorparent.common.viewmodels.LogsViewModel
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.parent.models.ChildInfo

class MessageLogFragment : Fragment(), OnClickTypeValue {
    private var _binding: FragmentMessageLogBinding? = null
    private val binding get() = _binding!!
    private val logsViewModel: LogsViewModel by activityViewModels()
    private val sharedViewModel: SharedViewModel<ChildInfo> by activityViewModels()
    private lateinit var adapter: LogAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMessageLogBinding.inflate(inflater, container, false)

        adapter = LogAdapter(emptyList<LogItem>(), this@MessageLogFragment)
        binding.messageLogRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.messageLogRecyclerView.adapter = adapter

        logsViewModel.messageLogs.observe(viewLifecycleOwner) { logs ->
            adapter.updateData(logs)
        }

        getChildInfo()
        return binding.root
    }

    private fun getChildInfo() {
        sharedViewModel.childInfo.observe(viewLifecycleOwner) { childInfo ->
            logsViewModel.fetchMessageLogs(requireContext(), childInfo.childId)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(position: Int, type: String, value: String) {
        TODO("Not yet implemented")
    }
}
