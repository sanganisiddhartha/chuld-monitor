package com.org.childmonitorparent.child.workmanagers

import android.content.Context
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import androidx.work.Worker
import androidx.work.WorkerParameters
import android.util.Log
import com.org.childmonitorparent.child.broadcast_receivers.DeviceAdminReceivers

class LockWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        lockPhone()  // 🔒 Lock the device
        return Result.success()
    }

    private fun lockPhone() {
        val devicePolicyManager =
            applicationContext.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(applicationContext, DeviceAdminReceivers::class.java)

        if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.lockNow()
            Log.d("LockWorker", "✅ Phone Locked")
        } else {
            Log.e("LockWorker", "❌ Admin permission required")
        }
    }
}
