package com.org.childmonitorparent.parent.activities

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.org.childmonitorparent.R
import com.org.childmonitorparent.auth.models.User
import com.org.childmonitorparent.common.viewmodels.SharedViewModel
import com.org.childmonitorparent.parent.adapters.ViewPagerAdapter
import com.org.childmonitorparent.databinding.ActivityChildLinkBinding

class ChildLinkActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChildLinkBinding
    private val sharedViewModel: SharedViewModel<User> by viewModels()
    private lateinit var user: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityChildLinkBinding.inflate(layoutInflater)
        setContentView(binding.root)
        user = intent.getSerializableExtra("user") as User
        sharedViewModel.setChildInfo(user)
        binding.viewPager.adapter = ViewPagerAdapter(this)
    }
}